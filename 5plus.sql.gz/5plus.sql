-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 27, 2019 at 06:02 PM
-- Server version: 10.1.41-MariaDB-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bh63703_5plus`
--

-- --------------------------------------------------------

--
-- Table structure for table `action`
--

CREATE TABLE `action` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `type` int(10) UNSIGNED NOT NULL COMMENT 'Тип записи',
  `admin_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID админа',
  `user_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID клиента',
  `group_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID группы',
  `amount` int(11) DEFAULT NULL COMMENT 'Сумма операции',
  `comment` text COLLATE utf8_unicode_ci COMMENT 'Комментарий к операции',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата операции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `auth`
--

CREATE TABLE `auth` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID пользователя',
  `source` varchar(50) NOT NULL COMMENT 'Источник',
  `source_id` varchar(255) NOT NULL COMMENT 'Идентификатор в системе источника'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID компании',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Официальное название',
  `second_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Формальное название',
  `licence` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Лицензия',
  `head_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Имя директора',
  `head_name_short` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Имя директора кратко',
  `zip` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Индекс',
  `city` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Город',
  `address` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Адрес',
  `phone` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Телефон',
  `tin` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'ИНН',
  `bank_data` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Банковские реквизиты',
  `oked` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'ОКЭД',
  `mfo` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'МФО'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contract`
--

CREATE TABLE `contract` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `number` varchar(20) NOT NULL COMMENT 'Номер договора',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID ученика',
  `group_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Группа',
  `company_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Компания',
  `amount` int(10) UNSIGNED NOT NULL COMMENT 'Сумма',
  `discount` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Со скидкой',
  `status` tinyint(4) DEFAULT '0' COMMENT 'Статус оплаты',
  `payment_type` tinyint(4) DEFAULT NULL COMMENT 'Тип оплаты',
  `external_id` varchar(50) DEFAULT NULL COMMENT 'ID транзакции в платёжной системе',
  `created_at` datetime DEFAULT NULL COMMENT 'Дата создания',
  `created_admin_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Кто добавил',
  `paid_at` datetime DEFAULT NULL COMMENT 'Дата оплаты',
  `paid_admin_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Кто отметил оплаченным'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `debt`
--

CREATE TABLE `debt` (
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID должника',
  `group_id` int(10) UNSIGNED NOT NULL COMMENT 'Группа',
  `amount` float NOT NULL COMMENT 'Сумма задолженности',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Когда появился долг'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `email_queue`
--

CREATE TABLE `email_queue` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `template_html` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'HTML-шаблон',
  `template_text` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Текстовый шаблон',
  `params` longtext COLLATE utf8_unicode_ci COMMENT 'Параметры для передачи в шаблон',
  `sender` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Отправитель',
  `recipient` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Получатель',
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Тема',
  `state` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Статус отправки',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата добавления',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Дата изменения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `errors`
--

CREATE TABLE `errors` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `module` varchar(255) NOT NULL COMMENT 'Место ошибки',
  `content` text NOT NULL COMMENT 'Содержимое ошибки',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Время возникновения ошибки'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `group_id` int(10) UNSIGNED NOT NULL COMMENT 'ID группы',
  `event_date` datetime NOT NULL COMMENT 'Дата занятия',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Статус занятия'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `event_member`
--

CREATE TABLE `event_member` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `group_pupil_id` int(10) UNSIGNED NOT NULL COMMENT 'ID ученика в группе',
  `event_id` int(10) UNSIGNED NOT NULL COMMENT 'ID занятия',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Статус присутствия',
  `mark` tinyint(4) DEFAULT NULL COMMENT 'Оценка'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `gift_card`
--

CREATE TABLE `gift_card` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `name` varchar(127) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `amount` int(10) UNSIGNED NOT NULL COMMENT 'Номинал',
  `code` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Проверочный код',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Статус',
  `customer_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ФИО покупателя',
  `customer_phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Телефон покупателя',
  `customer_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'E-mail покупателя',
  `additional` text COLLATE utf8_unicode_ci COMMENT 'Дополнительная информация',
  `created_at` datetime NOT NULL COMMENT 'Дата добавления',
  `paid_at` datetime DEFAULT NULL COMMENT 'Дата оплаты',
  `used_at` datetime DEFAULT NULL COMMENT 'Дата активации'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gift_card_type`
--

CREATE TABLE `gift_card_type` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `name` varchar(127) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `amount` int(10) UNSIGNED NOT NULL COMMENT 'Номинал',
  `email_html` text COLLATE utf8_unicode_ci COMMENT 'Письмо HTML',
  `email_text` text COLLATE utf8_unicode_ci COMMENT 'Письмо текстовое',
  `active` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Доступна для покупки'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE `group` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID группы',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название группы',
  `legal_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Официальное название (для договора)',
  `type_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Тип группы',
  `subject_id` int(10) UNSIGNED NOT NULL COMMENT 'ID предмета',
  `teacher_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID учителя',
  `schedule` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'График занятий группы',
  `lesson_price` int(10) UNSIGNED NOT NULL COMMENT 'Цена занятия',
  `lesson_price_discount` int(10) UNSIGNED DEFAULT NULL COMMENT 'Цена занятия со скидкой',
  `teacher_rate` float NOT NULL DEFAULT '0' COMMENT 'Процент начислений зарплаты учителю',
  `room_number` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Номер кабинета',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Занимается ли группа',
  `date_start` date DEFAULT NULL COMMENT 'Дата начала занятий',
  `date_end` date DEFAULT NULL COMMENT 'Дата завершения занятий'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `group_param`
--

CREATE TABLE `group_param` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `group_id` int(10) UNSIGNED NOT NULL COMMENT 'Группа',
  `year` smallint(5) UNSIGNED NOT NULL COMMENT 'год',
  `month` tinyint(3) UNSIGNED NOT NULL COMMENT 'месяц',
  `lesson_price` int(10) UNSIGNED NOT NULL COMMENT 'Цена занятия',
  `lesson_price_discount` int(10) UNSIGNED DEFAULT NULL COMMENT 'Цена занятия со скидкой',
  `schedule` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'График занятий группы ',
  `teacher_id` int(10) UNSIGNED NOT NULL COMMENT 'Учитель',
  `teacher_rate` float NOT NULL COMMENT 'Процент учителю',
  `teacher_salary` int(10) UNSIGNED DEFAULT NULL COMMENT 'Зарплата учителя'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `group_pupil`
--

CREATE TABLE `group_pupil` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID ученика',
  `group_id` int(10) UNSIGNED NOT NULL COMMENT 'ID группы',
  `active` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Активен ли студент',
  `date_start` date DEFAULT NULL COMMENT 'Дата начала занятий в группу',
  `date_end` date DEFAULT NULL COMMENT 'Дата завершения занятий в группе',
  `moved` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Перешёл в другую группу',
  `date_charge_till` timestamp NULL DEFAULT NULL COMMENT 'Стоимость списана до этой даты',
  `paid_lessons` int(11) NOT NULL DEFAULT '0' COMMENT 'Сколько оплаченных занятий осталось'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `group_type`
--

CREATE TABLE `group_type` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `high_school`
--

CREATE TABLE `high_school` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID ВУЗа',
  `type` tinyint(4) NOT NULL COMMENT 'Тип учебного заведения',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название учебного заведения',
  `name_short` varchar(127) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Аббревиатура',
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Фото',
  `short_description` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Краткое описание',
  `description` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Полное описание',
  `page_order` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Порядок отображения на странице',
  `active` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Показывать'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `language_id` tinyint(3) UNSIGNED NOT NULL,
  `language_code` char(3) DEFAULT NULL,
  `language_name` varchar(30) DEFAULT NULL,
  `language_active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `language_default` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `controller` char(50) DEFAULT NULL,
  `action` char(50) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `url_prefix` varchar(50) DEFAULT NULL COMMENT 'Префикс URL',
  `field_for_url` varchar(50) DEFAULT NULL COMMENT 'Поле, которое использовать для генерации URL',
  `field_for_title` varchar(50) DEFAULT NULL COMMENT 'Поле, из которого скопировать Title',
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_blog`
--

CREATE TABLE `module_blog` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID статьи',
  `name` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Заголовок',
  `image` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Картинка',
  `content` text COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Контент',
  `webpage_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Активен',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата публикакции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `module_feedback`
--

CREATE TABLE `module_feedback` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID сообщения',
  `name` varchar(50) NOT NULL COMMENT 'Имя пользователя',
  `contact` varchar(255) NOT NULL COMMENT 'Как с ним связаться',
  `message` text NOT NULL COMMENT 'Сообщение',
  `ip` varchar(40) NOT NULL COMMENT 'IP адрес отправителя',
  `status` enum('new','read','completed') NOT NULL DEFAULT 'new' COMMENT 'Статус',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_order`
--

CREATE TABLE `module_order` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `source` varchar(50) DEFAULT NULL COMMENT 'Источник заявки',
  `subject` varchar(127) NOT NULL COMMENT 'Предмет',
  `name` varchar(50) NOT NULL COMMENT 'Имя',
  `phone` char(13) NOT NULL COMMENT 'Телефон',
  `email` varchar(50) DEFAULT NULL COMMENT 'E-mail',
  `status` enum('unread','read','done','problem') NOT NULL DEFAULT 'unread' COMMENT 'Статус заявки',
  `user_comment` varchar(255) DEFAULT NULL COMMENT 'Комментарии от заказчика',
  `admin_comment` varchar(255) DEFAULT NULL COMMENT 'Комментарии админа',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата подачи'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_order_subject`
--

CREATE TABLE `module_order_subject` (
  `name` varchar(127) NOT NULL COMMENT 'Название предмета'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_page`
--

CREATE TABLE `module_page` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `title` varchar(255) NOT NULL COMMENT 'Заголовок',
  `content` text NOT NULL COMMENT 'Содержимое',
  `webpage_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'ID webpage',
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'активна',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_promotions`
--

CREATE TABLE `module_promotions` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID акции',
  `name` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Заголовок',
  `image` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Картинка',
  `content` text COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Контент',
  `webpage_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Активен',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата акции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `module_review`
--

CREATE TABLE `module_review` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID отзыва',
  `name` varchar(50) NOT NULL COMMENT 'Имя автора',
  `age` tinyint(4) DEFAULT NULL COMMENT 'Возраст автора',
  `message` varchar(1000) NOT NULL COMMENT 'Текст отзыва',
  `status` enum('new','approved') NOT NULL DEFAULT 'new' COMMENT 'Статус отзыва',
  `ip` varchar(40) NOT NULL COMMENT 'IP адрес отправителя',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_subject`
--

CREATE TABLE `module_subject` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID предмета',
  `name` varchar(50) NOT NULL COMMENT 'Название предмета',
  `category_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID группы',
  `image` varchar(255) DEFAULT NULL COMMENT 'Картинка',
  `description` text NOT NULL COMMENT 'Тизер',
  `content` text NOT NULL COMMENT 'Контент',
  `webpage_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `bitrix_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Bitrix ID',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Активен'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_subject_category`
--

CREATE TABLE `module_subject_category` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'id',
  `name` varchar(255) NOT NULL COMMENT 'Название группы',
  `webpage_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `page_order` int(11) DEFAULT '0' COMMENT 'Порядок отображения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `notify`
--

CREATE TABLE `notify` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID студента',
  `group_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Группа',
  `template_id` int(10) UNSIGNED NOT NULL COMMENT 'ID шаблона',
  `params` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Параметры для сообщения',
  `status` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Статус отправки сообщения',
  `created_at` datetime NOT NULL COMMENT 'Дата создания',
  `sent_at` datetime DEFAULT NULL COMMENT 'Дата успешной отправки',
  `attempts` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Попыток отправки'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID студента',
  `admin_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID админа',
  `group_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Группа',
  `amount` int(11) NOT NULL COMMENT 'Сумма',
  `discount` tinyint(4) DEFAULT '0' COMMENT 'Скидочный платёж',
  `comment` text COLLATE utf8_unicode_ci COMMENT 'Комментарий',
  `contract_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID договора',
  `used_payment_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID использованного при списании платежа',
  `event_member_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID занятия',
  `cash_received` tinyint(3) UNSIGNED DEFAULT '1' COMMENT 'Получены ли физически денежные средства',
  `bitrix_sync_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Статус синхронизации с Bitrix',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата операции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `payment_link`
--

CREATE TABLE `payment_link` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `hash_key` varchar(25) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ключ',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'Студент',
  `group_id` int(10) UNSIGNED NOT NULL COMMENT 'Группа'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_botan_shortener`
--

CREATE TABLE `ptg_botan_shortener` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `url` text COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Original URL',
  `short_url` char(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Shortened URL',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_callback_query`
--

CREATE TABLE `ptg_callback_query` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this query',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Unique message identifier',
  `inline_message_id` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the message sent via the bot in inline mode, that originated the query',
  `data` char(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Data associated with the callback button',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_chat`
--

CREATE TABLE `ptg_chat` (
  `id` bigint(20) NOT NULL COMMENT 'Unique user or chat identifier',
  `type` enum('private','group','supergroup','channel') COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Chat type, either private, group, supergroup or channel',
  `title` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT '' COMMENT 'Chat (group) title, is null if chat type is private',
  `username` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Username, for private chats, supergroups and channels if available',
  `all_members_are_administrators` tinyint(1) DEFAULT '0' COMMENT 'True if a all members of this group are admins',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update',
  `old_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier, this is filled when a group is converted to a supergroup'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_chosen_inline_result`
--

CREATE TABLE `ptg_chosen_inline_result` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `result_id` char(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Identifier for this result',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `location` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Location object, user''s location',
  `inline_message_id` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the sent inline message',
  `query` text COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'The query that was used to obtain the result',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_conversation`
--

CREATE TABLE `ptg_conversation` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Unique user or chat identifier',
  `status` enum('active','cancelled','stopped') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active' COMMENT 'Conversation state',
  `command` varchar(160) COLLATE utf8mb4_unicode_520_ci DEFAULT '' COMMENT 'Default command to execute',
  `notes` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Data stored from command',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_edited_message`
--

CREATE TABLE `ptg_edited_message` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Unique message identifier',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `edit_date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was edited in timestamp format',
  `text` text COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, the actual UTF-8 text of the message max message length 4096 char utf8',
  `entities` text COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, special entities like usernames, URLs, bot commands, etc. that appear in the text',
  `caption` text COLLATE utf8mb4_unicode_520_ci COMMENT 'For message with caption, the actual UTF-8 text of the caption'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_inline_query`
--

CREATE TABLE `ptg_inline_query` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this query',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `location` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Location of the user',
  `query` text COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Text of the query',
  `offset` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Offset of the result',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_message`
--

CREATE TABLE `ptg_message` (
  `chat_id` bigint(20) NOT NULL COMMENT 'Unique chat identifier',
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique message identifier',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was sent in timestamp format',
  `forward_from` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier, sender of the original message',
  `forward_from_chat` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier, chat the original message belongs to',
  `forward_from_message_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier of the original message in the channel',
  `forward_date` timestamp NULL DEFAULT NULL COMMENT 'date the original message was sent in timestamp format',
  `reply_to_chat` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier',
  `reply_to_message` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Message that this message is reply to',
  `media_group_id` text COLLATE utf8mb4_unicode_520_ci COMMENT 'The unique identifier of a media message group this message belongs to',
  `text` text COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, the actual UTF-8 text of the message max message length 4096 char utf8mb4',
  `entities` text COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, special entities like usernames, URLs, bot commands, etc. that appear in the text',
  `audio` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Audio object. Message is an audio file, information about the file',
  `document` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Document object. Message is a general file, information about the file',
  `game` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Game object. Message is a game, information about the game',
  `photo` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Array of PhotoSize objects. Message is a photo, available sizes of the photo',
  `sticker` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Sticker object. Message is a sticker, information about the sticker',
  `video` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Video object. Message is a video, information about the video',
  `voice` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Voice Object. Message is a Voice, information about the Voice',
  `video_note` text COLLATE utf8mb4_unicode_520_ci COMMENT 'VoiceNote Object. Message is a Video Note, information about the Video Note',
  `contact` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Contact object. Message is a shared contact, information about the contact',
  `location` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Location object. Message is a shared location, information about the location',
  `venue` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Venue object. Message is a Venue, information about the Venue',
  `caption` text COLLATE utf8mb4_unicode_520_ci COMMENT 'For message with caption, the actual UTF-8 text of the caption',
  `new_chat_members` text COLLATE utf8mb4_unicode_520_ci COMMENT 'List of unique user identifiers, new member(s) were added to the group, information about them (one of these members may be the bot itself)',
  `left_chat_member` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier, a member was removed from the group, information about them (this member may be the bot itself)',
  `new_chat_title` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'A chat title was changed to this value',
  `new_chat_photo` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Array of PhotoSize objects. A chat photo was change to this value',
  `delete_chat_photo` tinyint(1) DEFAULT '0' COMMENT 'Informs that the chat photo was deleted',
  `group_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the group has been created',
  `supergroup_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the supergroup has been created',
  `channel_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the channel chat has been created',
  `migrate_to_chat_id` bigint(20) DEFAULT NULL COMMENT 'Migrate to chat identifier. The group has been migrated to a supergroup with the specified identifier',
  `migrate_from_chat_id` bigint(20) DEFAULT NULL COMMENT 'Migrate from chat identifier. The supergroup has been migrated from a group with the specified identifier',
  `pinned_message` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Message object. Specified message was pinned',
  `connected_website` text COLLATE utf8mb4_unicode_520_ci COMMENT 'The domain name of the website on which the user has logged in.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_request_limiter`
--

CREATE TABLE `ptg_request_limiter` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `chat_id` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Unique chat identifier',
  `inline_message_id` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the sent inline message',
  `method` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Request method',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_telegram_update`
--

CREATE TABLE `ptg_telegram_update` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Update''s unique identifier',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Unique message identifier',
  `inline_query_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Unique inline query identifier',
  `chosen_inline_result_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Local chosen inline result identifier',
  `callback_query_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Unique callback query identifier',
  `edited_message_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Local edited message identifier'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_user`
--

CREATE TABLE `ptg_user` (
  `id` bigint(20) NOT NULL COMMENT 'Unique user identifier',
  `is_bot` tinyint(1) DEFAULT '0' COMMENT 'True if this user is a bot',
  `first_name` char(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'User''s first name',
  `last_name` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'User''s last name',
  `username` char(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'User''s username',
  `language_code` char(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'User''s system language',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_user_chat`
--

CREATE TABLE `ptg_user_chat` (
  `user_id` bigint(20) NOT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint(20) NOT NULL COMMENT 'Unique user or chat identifier'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `quiz_id` int(10) UNSIGNED NOT NULL COMMENT 'ID теста',
  `parent_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Вопрос',
  `content` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Текст вопроса/ответа',
  `is_right` tinyint(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Правильный ответ',
  `sort_order` int(10) UNSIGNED DEFAULT NULL COMMENT 'Порядок вопроса'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID теста',
  `subject_id` int(10) UNSIGNED NOT NULL COMMENT 'ID предмета',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `page_order` int(10) UNSIGNED DEFAULT NULL COMMENT 'Порядок отображения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_result`
--

CREATE TABLE `quiz_result` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ключ записи',
  `student_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Имя студента',
  `subject_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название предмета',
  `quiz_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название теста',
  `questions_data` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT 'Вопросы',
  `answers_data` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Ответы',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Время начала теста',
  `finished_at` timestamp NULL DEFAULT NULL COMMENT 'Время завершения теста'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID учителя',
  `name` varchar(127) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ФИО',
  `phone` char(13) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Телефон',
  `birthday` date DEFAULT NULL COMMENT 'День рождения',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Как представлять учителя',
  `description` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Описание',
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Фото',
  `webpage_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `page_visibility` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Отображать на странице учителей',
  `page_order` int(11) NOT NULL DEFAULT '0' COMMENT 'Порядок отображения на странице учителей',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Работает ли учитель'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_subject`
--

CREATE TABLE `teacher_subject` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `teacher_id` int(10) UNSIGNED NOT NULL COMMENT 'ID учителя',
  `subject_id` int(10) UNSIGNED NOT NULL COMMENT 'ID предмета'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `tg_botan_shortener`
--

CREATE TABLE `tg_botan_shortener` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `url` text COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Original URL',
  `short_url` char(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Shortened URL',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_callback_query`
--

CREATE TABLE `tg_callback_query` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this query',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Unique message identifier',
  `inline_message_id` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the message sent via the bot in inline mode, that originated the query',
  `data` char(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Data associated with the callback button',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_chat`
--

CREATE TABLE `tg_chat` (
  `id` bigint(20) NOT NULL COMMENT 'Unique user or chat identifier',
  `type` enum('private','group','supergroup','channel') COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Chat type, either private, group, supergroup or channel',
  `title` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT '' COMMENT 'Chat (group) title, is null if chat type is private',
  `username` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Username, for private chats, supergroups and channels if available',
  `all_members_are_administrators` tinyint(1) DEFAULT '0' COMMENT 'True if a all members of this group are admins',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update',
  `old_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier, this is filled when a group is converted to a supergroup'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_chosen_inline_result`
--

CREATE TABLE `tg_chosen_inline_result` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `result_id` char(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Identifier for this result',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `location` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Location object, user''s location',
  `inline_message_id` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the sent inline message',
  `query` text COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'The query that was used to obtain the result',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_conversation`
--

CREATE TABLE `tg_conversation` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Unique user or chat identifier',
  `status` enum('active','cancelled','stopped') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active' COMMENT 'Conversation state',
  `command` varchar(160) COLLATE utf8mb4_unicode_520_ci DEFAULT '' COMMENT 'Default command to execute',
  `notes` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Data stored from command',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_edited_message`
--

CREATE TABLE `tg_edited_message` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Unique message identifier',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `edit_date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was edited in timestamp format',
  `text` text COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, the actual UTF-8 text of the message max message length 4096 char utf8',
  `entities` text COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, special entities like usernames, URLs, bot commands, etc. that appear in the text',
  `caption` text COLLATE utf8mb4_unicode_520_ci COMMENT 'For message with caption, the actual UTF-8 text of the caption'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_inline_query`
--

CREATE TABLE `tg_inline_query` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this query',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `location` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Location of the user',
  `query` text COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Text of the query',
  `offset` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Offset of the result',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_message`
--

CREATE TABLE `tg_message` (
  `chat_id` bigint(20) NOT NULL COMMENT 'Unique chat identifier',
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique message identifier',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was sent in timestamp format',
  `forward_from` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier, sender of the original message',
  `forward_from_chat` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier, chat the original message belongs to',
  `forward_from_message_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier of the original message in the channel',
  `forward_date` timestamp NULL DEFAULT NULL COMMENT 'date the original message was sent in timestamp format',
  `reply_to_chat` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier',
  `reply_to_message` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Message that this message is reply to',
  `media_group_id` text COLLATE utf8mb4_unicode_520_ci COMMENT 'The unique identifier of a media message group this message belongs to',
  `text` text COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, the actual UTF-8 text of the message max message length 4096 char utf8mb4',
  `entities` text COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, special entities like usernames, URLs, bot commands, etc. that appear in the text',
  `audio` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Audio object. Message is an audio file, information about the file',
  `document` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Document object. Message is a general file, information about the file',
  `game` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Game object. Message is a game, information about the game',
  `photo` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Array of PhotoSize objects. Message is a photo, available sizes of the photo',
  `sticker` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Sticker object. Message is a sticker, information about the sticker',
  `video` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Video object. Message is a video, information about the video',
  `voice` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Voice Object. Message is a Voice, information about the Voice',
  `video_note` text COLLATE utf8mb4_unicode_520_ci COMMENT 'VoiceNote Object. Message is a Video Note, information about the Video Note',
  `contact` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Contact object. Message is a shared contact, information about the contact',
  `location` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Location object. Message is a shared location, information about the location',
  `venue` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Venue object. Message is a Venue, information about the Venue',
  `caption` text COLLATE utf8mb4_unicode_520_ci COMMENT 'For message with caption, the actual UTF-8 text of the caption',
  `new_chat_members` text COLLATE utf8mb4_unicode_520_ci COMMENT 'List of unique user identifiers, new member(s) were added to the group, information about them (one of these members may be the bot itself)',
  `left_chat_member` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier, a member was removed from the group, information about them (this member may be the bot itself)',
  `new_chat_title` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'A chat title was changed to this value',
  `new_chat_photo` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Array of PhotoSize objects. A chat photo was change to this value',
  `delete_chat_photo` tinyint(1) DEFAULT '0' COMMENT 'Informs that the chat photo was deleted',
  `group_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the group has been created',
  `supergroup_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the supergroup has been created',
  `channel_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the channel chat has been created',
  `migrate_to_chat_id` bigint(20) DEFAULT NULL COMMENT 'Migrate to chat identifier. The group has been migrated to a supergroup with the specified identifier',
  `migrate_from_chat_id` bigint(20) DEFAULT NULL COMMENT 'Migrate from chat identifier. The supergroup has been migrated from a group with the specified identifier',
  `pinned_message` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Message object. Specified message was pinned',
  `connected_website` text COLLATE utf8mb4_unicode_520_ci COMMENT 'The domain name of the website on which the user has logged in.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_request_limiter`
--

CREATE TABLE `tg_request_limiter` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `chat_id` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Unique chat identifier',
  `inline_message_id` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the sent inline message',
  `method` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Request method',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_telegram_update`
--

CREATE TABLE `tg_telegram_update` (
  `id` bigint(20) UNSIGNED NOT NULL COMMENT 'Update''s unique identifier',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Unique message identifier',
  `inline_query_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Unique inline query identifier',
  `chosen_inline_result_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Local chosen inline result identifier',
  `callback_query_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Unique callback query identifier',
  `edited_message_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Local edited message identifier'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_user`
--

CREATE TABLE `tg_user` (
  `id` bigint(20) NOT NULL COMMENT 'Unique user identifier',
  `is_bot` tinyint(1) DEFAULT '0' COMMENT 'True if this user is a bot',
  `first_name` char(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'User''s first name',
  `last_name` char(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'User''s last name',
  `username` char(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'User''s username',
  `language_code` char(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'User''s system language',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_user_chat`
--

CREATE TABLE `tg_user_chat` (
  `user_id` bigint(20) NOT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint(20) NOT NULL COMMENT 'Unique user or chat identifier'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tinified`
--

CREATE TABLE `tinified` (
  `fileName` varchar(127) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `checksum` char(40) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(127) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Имя пользователя',
  `note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Заметки',
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` char(13) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Телефон',
  `phone2` char(13) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Доп. телефон',
  `tg_chat_id` bigint(20) DEFAULT NULL COMMENT 'Telegram chat ID',
  `bitrix_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Bitrix ID',
  `status` smallint(6) NOT NULL DEFAULT '10',
  `money` int(11) NOT NULL DEFAULT '0' COMMENT 'Баланс',
  `role` tinyint(4) NOT NULL COMMENT 'Уровень доступа пользователя',
  `parent_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Родитель',
  `bitrix_sync_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Статус синхронизации с Bitrix',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата создания',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Дата изменения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `user_call`
--

CREATE TABLE `user_call` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID студента',
  `admin_id` int(10) UNSIGNED NOT NULL COMMENT 'ID админа',
  `comment` text CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'Комментарий',
  `created_at` datetime NOT NULL COMMENT 'Дата звонка'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `group_id` tinyint(3) UNSIGNED NOT NULL,
  `group_name` varchar(127) NOT NULL,
  `group_description` varchar(255) DEFAULT NULL,
  `group_active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `webpage`
--

CREATE TABLE `webpage` (
  `id` int(11) UNSIGNED NOT NULL,
  `url` char(255) NOT NULL DEFAULT '',
  `main` tinyint(1) UNSIGNED DEFAULT NULL,
  `title` char(255) DEFAULT NULL,
  `description` text,
  `keywords` text,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `module_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `record_id` int(11) UNSIGNED DEFAULT NULL,
  `inrobots` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `welcome_lesson`
--

CREATE TABLE `welcome_lesson` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID студента',
  `subject_id` int(10) UNSIGNED NOT NULL COMMENT 'ID предмета',
  `teacher_id` int(10) UNSIGNED NOT NULL COMMENT 'ID учителя',
  `lesson_date` datetime NOT NULL COMMENT 'Дата занятия',
  `status` tinyint(4) DEFAULT NULL COMMENT 'Статус занятия',
  `bitrix_sync_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Статус синхронизации с Bitrix'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `widget_html`
--

CREATE TABLE `widget_html` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `editor` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Визуальный редактор'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `widget_menu`
--

CREATE TABLE `widget_menu` (
  `id` tinyint(3) UNSIGNED NOT NULL COMMENT 'ID',
  `name` varchar(63) NOT NULL COMMENT 'Название меню',
  `title` varchar(255) DEFAULT NULL COMMENT 'Заголовок меню',
  `language_id` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Язык'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `widget_menu_item`
--

CREATE TABLE `widget_menu_item` (
  `id` int(11) UNSIGNED NOT NULL COMMENT 'ID',
  `menu_id` tinyint(3) UNSIGNED NOT NULL COMMENT 'Меню',
  `parent_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Родительский пункт меню',
  `webpage_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Ссылка на страницу сайта',
  `url` varchar(255) DEFAULT NULL COMMENT 'URL',
  `title` varchar(127) DEFAULT NULL COMMENT 'Текст пункта меню',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Показывать или нет',
  `attr` text COMMENT 'Доп параметры',
  `orderby` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Порядок'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `action`
--
ALTER TABLE `action`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `admin_id` (`admin_id`) USING BTREE,
  ADD KEY `user_id` (`user_id`) USING BTREE,
  ADD KEY `group_id` (`group_id`) USING BTREE;

--
-- Indexes for table `auth`
--
ALTER TABLE `auth`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auth_user_id_fk` (`user_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contract_number_uindex` (`number`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `contract_group_id_index` (`group_id`),
  ADD KEY `contract_created_user_id_fk` (`created_admin_id`),
  ADD KEY `contract_paid_user_id_fk` (`paid_admin_id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `debt`
--
ALTER TABLE `debt`
  ADD PRIMARY KEY (`user_id`,`group_id`),
  ADD KEY `group_id` (`group_id`);

--
-- Indexes for table `email_queue`
--
ALTER TABLE `email_queue`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `errors`
--
ALTER TABLE `errors`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `group_id` (`group_id`) USING BTREE;

--
-- Indexes for table `event_member`
--
ALTER TABLE `event_member`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `event_id` (`event_id`) USING BTREE,
  ADD KEY `group_pupil_id` (`group_pupil_id`);

--
-- Indexes for table `gift_card`
--
ALTER TABLE `gift_card`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `gift_card_type`
--
ALTER TABLE `gift_card_type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `active` (`active`);

--
-- Indexes for table `group`
--
ALTER TABLE `group`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `subject_id` (`subject_id`) USING BTREE,
  ADD KEY `teacher_id` (`teacher_id`) USING BTREE,
  ADD KEY `group_group_type_id_fk` (`type_id`);

--
-- Indexes for table `group_param`
--
ALTER TABLE `group_param`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `group_id` (`group_id`,`year`,`month`) USING BTREE,
  ADD KEY `teacher_id` (`teacher_id`) USING BTREE;

--
-- Indexes for table `group_pupil`
--
ALTER TABLE `group_pupil`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `user_id` (`user_id`) USING BTREE,
  ADD KEY `group_id` (`group_id`) USING BTREE;

--
-- Indexes for table `group_type`
--
ALTER TABLE `group_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `high_school`
--
ALTER TABLE `high_school`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`language_id`) USING BTREE,
  ADD UNIQUE KEY `language_code` (`language_code`) USING BTREE;

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `module_ukey` (`controller`,`action`) USING BTREE;

--
-- Indexes for table `module_blog`
--
ALTER TABLE `module_blog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `module_blog_ibfk_3` (`webpage_id`) USING BTREE;

--
-- Indexes for table `module_feedback`
--
ALTER TABLE `module_feedback`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `module_order`
--
ALTER TABLE `module_order`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `subject` (`subject`) USING BTREE;

--
-- Indexes for table `module_order_subject`
--
ALTER TABLE `module_order_subject`
  ADD PRIMARY KEY (`name`) USING BTREE;

--
-- Indexes for table `module_page`
--
ALTER TABLE `module_page`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `page_webpage_id` (`webpage_id`) USING BTREE;

--
-- Indexes for table `module_promotions`
--
ALTER TABLE `module_promotions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `module_promotions_ibfk_3` (`webpage_id`) USING BTREE;

--
-- Indexes for table `module_review`
--
ALTER TABLE `module_review`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `module_subject`
--
ALTER TABLE `module_subject`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `name` (`name`,`category_id`) USING BTREE,
  ADD KEY `category_id` (`category_id`) USING BTREE,
  ADD KEY `webpage_id` (`webpage_id`);

--
-- Indexes for table `module_subject_category`
--
ALTER TABLE `module_subject_category`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `webpage_id` (`webpage_id`);

--
-- Indexes for table `notify`
--
ALTER TABLE `notify`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `notify_group_id_fk` (`group_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `admin_id` (`admin_id`) USING BTREE,
  ADD KEY `user_id` (`user_id`) USING BTREE,
  ADD KEY `used_payment_id` (`used_payment_id`) USING BTREE,
  ADD KEY `event_member_id` (`event_member_id`),
  ADD KEY `contract_id` (`contract_id`),
  ADD KEY `payment_cms_group_id_fk` (`group_id`);

--
-- Indexes for table `payment_link`
--
ALTER TABLE `payment_link`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`hash_key`),
  ADD UNIQUE KEY `user_id_2` (`user_id`,`group_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `group_id` (`group_id`);

--
-- Indexes for table `ptg_botan_shortener`
--
ALTER TABLE `ptg_botan_shortener`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `ptg_callback_query`
--
ALTER TABLE `ptg_callback_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `chat_id_2` (`chat_id`,`message_id`);

--
-- Indexes for table `ptg_chat`
--
ALTER TABLE `ptg_chat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `old_id` (`old_id`);

--
-- Indexes for table `ptg_chosen_inline_result`
--
ALTER TABLE `ptg_chosen_inline_result`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `ptg_conversation`
--
ALTER TABLE `ptg_conversation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `ptg_edited_message`
--
ALTER TABLE `ptg_edited_message`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `chat_id_2` (`chat_id`,`message_id`);

--
-- Indexes for table `ptg_inline_query`
--
ALTER TABLE `ptg_inline_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `ptg_message`
--
ALTER TABLE `ptg_message`
  ADD PRIMARY KEY (`chat_id`,`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `forward_from` (`forward_from`),
  ADD KEY `forward_from_chat` (`forward_from_chat`),
  ADD KEY `reply_to_chat` (`reply_to_chat`),
  ADD KEY `reply_to_message` (`reply_to_message`),
  ADD KEY `left_chat_member` (`left_chat_member`),
  ADD KEY `migrate_from_chat_id` (`migrate_from_chat_id`),
  ADD KEY `migrate_to_chat_id` (`migrate_to_chat_id`),
  ADD KEY `reply_to_chat_2` (`reply_to_chat`,`reply_to_message`);

--
-- Indexes for table `ptg_request_limiter`
--
ALTER TABLE `ptg_request_limiter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ptg_telegram_update`
--
ALTER TABLE `ptg_telegram_update`
  ADD PRIMARY KEY (`id`),
  ADD KEY `message_id` (`chat_id`,`message_id`),
  ADD KEY `inline_query_id` (`inline_query_id`),
  ADD KEY `chosen_inline_result_id` (`chosen_inline_result_id`),
  ADD KEY `callback_query_id` (`callback_query_id`),
  ADD KEY `edited_message_id` (`edited_message_id`);

--
-- Indexes for table `ptg_user`
--
ALTER TABLE `ptg_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `ptg_user_chat`
--
ALTER TABLE `ptg_user_chat`
  ADD PRIMARY KEY (`user_id`,`chat_id`),
  ADD KEY `chat_id` (`chat_id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `parent_id` (`parent_id`) USING BTREE,
  ADD KEY `quiz_id` (`quiz_id`) USING BTREE;

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `subject_id` (`subject_id`) USING BTREE;

--
-- Indexes for table `quiz_result`
--
ALTER TABLE `quiz_result`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `hash` (`hash`) USING BTREE;

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `active` (`active`) USING BTREE,
  ADD KEY `webpage_id` (`webpage_id`);

--
-- Indexes for table `teacher_subject`
--
ALTER TABLE `teacher_subject`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `teacher_id` (`teacher_id`) USING BTREE,
  ADD KEY `subject_id` (`subject_id`) USING BTREE;

--
-- Indexes for table `tg_botan_shortener`
--
ALTER TABLE `tg_botan_shortener`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tg_callback_query`
--
ALTER TABLE `tg_callback_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `chat_id_2` (`chat_id`,`message_id`);

--
-- Indexes for table `tg_chat`
--
ALTER TABLE `tg_chat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `old_id` (`old_id`);

--
-- Indexes for table `tg_chosen_inline_result`
--
ALTER TABLE `tg_chosen_inline_result`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tg_conversation`
--
ALTER TABLE `tg_conversation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `tg_edited_message`
--
ALTER TABLE `tg_edited_message`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `chat_id_2` (`chat_id`,`message_id`);

--
-- Indexes for table `tg_inline_query`
--
ALTER TABLE `tg_inline_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tg_message`
--
ALTER TABLE `tg_message`
  ADD PRIMARY KEY (`chat_id`,`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `forward_from` (`forward_from`),
  ADD KEY `forward_from_chat` (`forward_from_chat`),
  ADD KEY `reply_to_chat` (`reply_to_chat`),
  ADD KEY `reply_to_message` (`reply_to_message`),
  ADD KEY `left_chat_member` (`left_chat_member`),
  ADD KEY `migrate_from_chat_id` (`migrate_from_chat_id`),
  ADD KEY `migrate_to_chat_id` (`migrate_to_chat_id`),
  ADD KEY `reply_to_chat_2` (`reply_to_chat`,`reply_to_message`);

--
-- Indexes for table `tg_request_limiter`
--
ALTER TABLE `tg_request_limiter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tg_telegram_update`
--
ALTER TABLE `tg_telegram_update`
  ADD PRIMARY KEY (`id`),
  ADD KEY `message_id` (`chat_id`,`message_id`),
  ADD KEY `inline_query_id` (`inline_query_id`),
  ADD KEY `chosen_inline_result_id` (`chosen_inline_result_id`),
  ADD KEY `callback_query_id` (`callback_query_id`),
  ADD KEY `edited_message_id` (`edited_message_id`);

--
-- Indexes for table `tg_user`
--
ALTER TABLE `tg_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `tg_user_chat`
--
ALTER TABLE `tg_user_chat`
  ADD PRIMARY KEY (`user_id`,`chat_id`),
  ADD KEY `chat_id` (`chat_id`);

--
-- Indexes for table `tinified`
--
ALTER TABLE `tinified`
  ADD PRIMARY KEY (`fileName`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`) USING BTREE,
  ADD KEY `parent_id` (`parent_id`) USING BTREE,
  ADD KEY `money` (`money`) USING BTREE,
  ADD KEY `phone` (`phone`),
  ADD KEY `phone2` (`phone2`),
  ADD KEY `username` (`username`) USING BTREE,
  ADD KEY `name` (`name`);

--
-- Indexes for table `user_call`
--
ALTER TABLE `user_call`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`group_id`) USING BTREE;

--
-- Indexes for table `webpage`
--
ALTER TABLE `webpage`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `webpage_uk` (`url`) USING BTREE,
  ADD KEY `webpage_module` (`module_id`) USING BTREE;

--
-- Indexes for table `welcome_lesson`
--
ALTER TABLE `welcome_lesson`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `widget_html`
--
ALTER TABLE `widget_html`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `widget_menu`
--
ALTER TABLE `widget_menu`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `menu_language_id` (`language_id`) USING BTREE;

--
-- Indexes for table `widget_menu_item`
--
ALTER TABLE `widget_menu_item`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `menu_item_menu_id` (`menu_id`) USING BTREE,
  ADD KEY `menu_item_parent_id` (`parent_id`) USING BTREE,
  ADD KEY `menu_item_webpage_id` (`webpage_id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `action`
--
ALTER TABLE `action`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `auth`
--
ALTER TABLE `auth`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID компании';

--
-- AUTO_INCREMENT for table `contract`
--
ALTER TABLE `contract`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `email_queue`
--
ALTER TABLE `email_queue`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `errors`
--
ALTER TABLE `errors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `event_member`
--
ALTER TABLE `event_member`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `gift_card`
--
ALTER TABLE `gift_card`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `gift_card_type`
--
ALTER TABLE `gift_card_type`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `group`
--
ALTER TABLE `group`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID группы';

--
-- AUTO_INCREMENT for table `group_param`
--
ALTER TABLE `group_param`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `group_pupil`
--
ALTER TABLE `group_pupil`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `group_type`
--
ALTER TABLE `group_type`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `high_school`
--
ALTER TABLE `high_school`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID ВУЗа';

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `language_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `module_blog`
--
ALTER TABLE `module_blog`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID статьи';

--
-- AUTO_INCREMENT for table `module_feedback`
--
ALTER TABLE `module_feedback`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID сообщения';

--
-- AUTO_INCREMENT for table `module_order`
--
ALTER TABLE `module_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `module_page`
--
ALTER TABLE `module_page`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `module_promotions`
--
ALTER TABLE `module_promotions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID акции';

--
-- AUTO_INCREMENT for table `module_review`
--
ALTER TABLE `module_review`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID отзыва';

--
-- AUTO_INCREMENT for table `module_subject`
--
ALTER TABLE `module_subject`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID предмета';

--
-- AUTO_INCREMENT for table `module_subject_category`
--
ALTER TABLE `module_subject_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id';

--
-- AUTO_INCREMENT for table `notify`
--
ALTER TABLE `notify`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `payment_link`
--
ALTER TABLE `payment_link`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `ptg_botan_shortener`
--
ALTER TABLE `ptg_botan_shortener`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `ptg_chosen_inline_result`
--
ALTER TABLE `ptg_chosen_inline_result`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `ptg_conversation`
--
ALTER TABLE `ptg_conversation`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `ptg_edited_message`
--
ALTER TABLE `ptg_edited_message`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `ptg_request_limiter`
--
ALTER TABLE `ptg_request_limiter`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID теста';

--
-- AUTO_INCREMENT for table `quiz_result`
--
ALTER TABLE `quiz_result`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID учителя';

--
-- AUTO_INCREMENT for table `teacher_subject`
--
ALTER TABLE `teacher_subject`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `tg_botan_shortener`
--
ALTER TABLE `tg_botan_shortener`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `tg_chosen_inline_result`
--
ALTER TABLE `tg_chosen_inline_result`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `tg_conversation`
--
ALTER TABLE `tg_conversation`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `tg_edited_message`
--
ALTER TABLE `tg_edited_message`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `tg_request_limiter`
--
ALTER TABLE `tg_request_limiter`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_call`
--
ALTER TABLE `user_call`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `group_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `webpage`
--
ALTER TABLE `webpage`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `welcome_lesson`
--
ALTER TABLE `welcome_lesson`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `widget_html`
--
ALTER TABLE `widget_html`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `widget_menu`
--
ALTER TABLE `widget_menu`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `widget_menu_item`
--
ALTER TABLE `widget_menu_item`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- Constraints for dumped tables
--

--
-- Constraints for table `action`
--
ALTER TABLE `action`
  ADD CONSTRAINT `action_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `action_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `action_ibfk_3` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`);

--
-- Constraints for table `contract`
--
ALTER TABLE `contract`
  ADD CONSTRAINT `contract_created_user_id_fk` FOREIGN KEY (`created_admin_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `contract_group_id_fk` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `contract_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `contract_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  ADD CONSTRAINT `contract_paid_user_id_fk` FOREIGN KEY (`paid_admin_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `debt`
--
ALTER TABLE `debt`
  ADD CONSTRAINT `debt_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `debt_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `event`
--
ALTER TABLE `event`
  ADD CONSTRAINT `event_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `event_member`
--
ALTER TABLE `event_member`
  ADD CONSTRAINT `event_member_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `event_member_ibfk_2` FOREIGN KEY (`group_pupil_id`) REFERENCES `group_pupil` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `group`
--
ALTER TABLE `group`
  ADD CONSTRAINT `group_group_type_id_fk` FOREIGN KEY (`type_id`) REFERENCES `group_type` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `group_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `module_subject` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `group_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `group_param`
--
ALTER TABLE `group_param`
  ADD CONSTRAINT `group_param_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `group_param_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `group_pupil`
--
ALTER TABLE `group_pupil`
  ADD CONSTRAINT `group_pupil_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `group_pupil_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `module_blog`
--
ALTER TABLE `module_blog`
  ADD CONSTRAINT `module_blog_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `module_page`
--
ALTER TABLE `module_page`
  ADD CONSTRAINT `module_page_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `module_promotions`
--
ALTER TABLE `module_promotions`
  ADD CONSTRAINT `module_promotions_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `module_subject`
--
ALTER TABLE `module_subject`
  ADD CONSTRAINT `module_subject_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `module_subject_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `module_subject_ibfk_2` FOREIGN KEY (`webpage_id`) REFERENCES `webpage` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `module_subject_category`
--
ALTER TABLE `module_subject_category`
  ADD CONSTRAINT `module_subject_category_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `webpage` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `notify`
--
ALTER TABLE `notify`
  ADD CONSTRAINT `notify_group_id_fk` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `notify_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_cms_group_id_fk` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_ibfk_4` FOREIGN KEY (`used_payment_id`) REFERENCES `payment` (`id`),
  ADD CONSTRAINT `payment_ibfk_7` FOREIGN KEY (`event_member_id`) REFERENCES `event_member` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_ibfk_8` FOREIGN KEY (`contract_id`) REFERENCES `contract` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `payment_link`
--
ALTER TABLE `payment_link`
  ADD CONSTRAINT `payment_link_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_link_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ptg_botan_shortener`
--
ALTER TABLE `ptg_botan_shortener`
  ADD CONSTRAINT `ptg_botan_shortener_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_callback_query`
--
ALTER TABLE `ptg_callback_query`
  ADD CONSTRAINT `ptg_callback_query_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`),
  ADD CONSTRAINT `ptg_callback_query_ibfk_2` FOREIGN KEY (`chat_id`,`message_id`) REFERENCES `ptg_message` (`chat_id`, `id`);

--
-- Constraints for table `ptg_chosen_inline_result`
--
ALTER TABLE `ptg_chosen_inline_result`
  ADD CONSTRAINT `ptg_chosen_inline_result_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_conversation`
--
ALTER TABLE `ptg_conversation`
  ADD CONSTRAINT `ptg_conversation_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`),
  ADD CONSTRAINT `ptg_conversation_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `ptg_chat` (`id`);

--
-- Constraints for table `ptg_edited_message`
--
ALTER TABLE `ptg_edited_message`
  ADD CONSTRAINT `ptg_edited_message_ibfk_1` FOREIGN KEY (`chat_id`) REFERENCES `ptg_chat` (`id`),
  ADD CONSTRAINT `ptg_edited_message_ibfk_2` FOREIGN KEY (`chat_id`,`message_id`) REFERENCES `ptg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `ptg_edited_message_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_inline_query`
--
ALTER TABLE `ptg_inline_query`
  ADD CONSTRAINT `ptg_inline_query_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_message`
--
ALTER TABLE `ptg_message`
  ADD CONSTRAINT `ptg_message_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`),
  ADD CONSTRAINT `ptg_message_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `ptg_chat` (`id`),
  ADD CONSTRAINT `ptg_message_ibfk_3` FOREIGN KEY (`forward_from`) REFERENCES `ptg_user` (`id`),
  ADD CONSTRAINT `ptg_message_ibfk_4` FOREIGN KEY (`forward_from_chat`) REFERENCES `ptg_chat` (`id`),
  ADD CONSTRAINT `ptg_message_ibfk_5` FOREIGN KEY (`reply_to_chat`,`reply_to_message`) REFERENCES `ptg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `ptg_message_ibfk_6` FOREIGN KEY (`forward_from`) REFERENCES `ptg_user` (`id`),
  ADD CONSTRAINT `ptg_message_ibfk_7` FOREIGN KEY (`left_chat_member`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_telegram_update`
--
ALTER TABLE `ptg_telegram_update`
  ADD CONSTRAINT `ptg_telegram_update_ibfk_1` FOREIGN KEY (`chat_id`,`message_id`) REFERENCES `ptg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_2` FOREIGN KEY (`inline_query_id`) REFERENCES `ptg_inline_query` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_3` FOREIGN KEY (`chosen_inline_result_id`) REFERENCES `ptg_chosen_inline_result` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_4` FOREIGN KEY (`callback_query_id`) REFERENCES `ptg_callback_query` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_5` FOREIGN KEY (`edited_message_id`) REFERENCES `ptg_edited_message` (`id`);

--
-- Constraints for table `ptg_user_chat`
--
ALTER TABLE `ptg_user_chat`
  ADD CONSTRAINT `ptg_user_chat_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ptg_user_chat_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `ptg_chat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `question_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `question` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `module_subject` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teacher`
--
ALTER TABLE `teacher`
  ADD CONSTRAINT `teacher_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `webpage` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `teacher_subject`
--
ALTER TABLE `teacher_subject`
  ADD CONSTRAINT `teacher_subject_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`id`),
  ADD CONSTRAINT `teacher_subject_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `module_subject` (`id`);

--
-- Constraints for table `tg_botan_shortener`
--
ALTER TABLE `tg_botan_shortener`
  ADD CONSTRAINT `tg_botan_shortener_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_callback_query`
--
ALTER TABLE `tg_callback_query`
  ADD CONSTRAINT `tg_callback_query_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`),
  ADD CONSTRAINT `tg_callback_query_ibfk_2` FOREIGN KEY (`chat_id`,`message_id`) REFERENCES `tg_message` (`chat_id`, `id`);

--
-- Constraints for table `tg_chosen_inline_result`
--
ALTER TABLE `tg_chosen_inline_result`
  ADD CONSTRAINT `tg_chosen_inline_result_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_conversation`
--
ALTER TABLE `tg_conversation`
  ADD CONSTRAINT `tg_conversation_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`),
  ADD CONSTRAINT `tg_conversation_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `tg_chat` (`id`);

--
-- Constraints for table `tg_edited_message`
--
ALTER TABLE `tg_edited_message`
  ADD CONSTRAINT `tg_edited_message_ibfk_1` FOREIGN KEY (`chat_id`) REFERENCES `tg_chat` (`id`),
  ADD CONSTRAINT `tg_edited_message_ibfk_2` FOREIGN KEY (`chat_id`,`message_id`) REFERENCES `tg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `tg_edited_message_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_inline_query`
--
ALTER TABLE `tg_inline_query`
  ADD CONSTRAINT `tg_inline_query_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_message`
--
ALTER TABLE `tg_message`
  ADD CONSTRAINT `tg_message_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`),
  ADD CONSTRAINT `tg_message_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `tg_chat` (`id`),
  ADD CONSTRAINT `tg_message_ibfk_3` FOREIGN KEY (`forward_from`) REFERENCES `tg_user` (`id`),
  ADD CONSTRAINT `tg_message_ibfk_4` FOREIGN KEY (`forward_from_chat`) REFERENCES `tg_chat` (`id`),
  ADD CONSTRAINT `tg_message_ibfk_5` FOREIGN KEY (`reply_to_chat`,`reply_to_message`) REFERENCES `tg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `tg_message_ibfk_6` FOREIGN KEY (`forward_from`) REFERENCES `tg_user` (`id`),
  ADD CONSTRAINT `tg_message_ibfk_7` FOREIGN KEY (`left_chat_member`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_telegram_update`
--
ALTER TABLE `tg_telegram_update`
  ADD CONSTRAINT `tg_telegram_update_ibfk_1` FOREIGN KEY (`chat_id`,`message_id`) REFERENCES `tg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_2` FOREIGN KEY (`inline_query_id`) REFERENCES `tg_inline_query` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_3` FOREIGN KEY (`chosen_inline_result_id`) REFERENCES `tg_chosen_inline_result` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_4` FOREIGN KEY (`callback_query_id`) REFERENCES `tg_callback_query` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_5` FOREIGN KEY (`edited_message_id`) REFERENCES `tg_edited_message` (`id`);

--
-- Constraints for table `tg_user_chat`
--
ALTER TABLE `tg_user_chat`
  ADD CONSTRAINT `tg_user_chat_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tg_user_chat_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `tg_chat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `user` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `user_call`
--
ALTER TABLE `user_call`
  ADD CONSTRAINT `user_call_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_call_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `user` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `webpage`
--
ALTER TABLE `webpage`
  ADD CONSTRAINT `webpage_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `module` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `welcome_lesson`
--
ALTER TABLE `welcome_lesson`
  ADD CONSTRAINT `welcome_lesson_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `module_subject` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `welcome_lesson_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `welcome_lesson_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
