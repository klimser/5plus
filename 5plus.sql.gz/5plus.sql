-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 22, 2022 at 05:16 AM
-- Server version: 8.0.24
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `5plus`
--

-- --------------------------------------------------------

--
-- Table structure for table `action`
--

CREATE TABLE `action` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID записи',
  `type` int UNSIGNED NOT NULL COMMENT 'Тип записи',
  `admin_id` int UNSIGNED DEFAULT NULL COMMENT 'ID админа',
  `user_id` int UNSIGNED DEFAULT NULL COMMENT 'ID клиента',
  `group_id` int UNSIGNED DEFAULT NULL COMMENT 'ID группы',
  `amount` int DEFAULT NULL COMMENT 'Сумма операции',
  `comment` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Комментарий к операции',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата операции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `age_confirmation`
--

CREATE TABLE `age_confirmation` (
  `id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `phone` char(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'new',
  `attempt` tinyint UNSIGNED NOT NULL DEFAULT '0',
  `sent_at` datetime DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `valid_until` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth`
--

CREATE TABLE `auth` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID',
  `user_id` int UNSIGNED NOT NULL COMMENT 'ID пользователя',
  `source` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Источник',
  `source_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Идентификатор в системе источника'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bot_mailing`
--

CREATE TABLE `bot_mailing` (
  `id` int UNSIGNED NOT NULL,
  `admin_id` int UNSIGNED NOT NULL,
  `message_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `message_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `created_at` datetime NOT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bot_push`
--

CREATE TABLE `bot_push` (
  `id` int UNSIGNED NOT NULL,
  `chat_id` bigint NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `status` tinyint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID компании',
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Официальное название',
  `second_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Формальное название',
  `licence` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Лицензия',
  `head_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Имя директора',
  `head_name_short` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Имя директора кратко',
  `zip` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Индекс',
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Город',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Адрес',
  `address_school` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Адрес школы',
  `phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Телефон',
  `tin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'ИНН',
  `bank_data` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Банковские реквизиты',
  `oked` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'ОКЭД',
  `mfo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'МФО'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `confirmation_code`
--

CREATE TABLE `confirmation_code` (
  `id` int NOT NULL,
  `phone` char(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `valid_until` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `consultation`
--

CREATE TABLE `consultation` (
  `id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `subject_id` int UNSIGNED NOT NULL,
  `created_by` int UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contract`
--

CREATE TABLE `contract` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID',
  `number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Номер договора',
  `user_id` int UNSIGNED NOT NULL COMMENT 'ID ученика',
  `group_id` int UNSIGNED DEFAULT NULL COMMENT 'Группа',
  `company_id` int UNSIGNED DEFAULT NULL COMMENT 'Компания',
  `amount` int UNSIGNED NOT NULL COMMENT 'Сумма',
  `discount` tinyint NOT NULL DEFAULT '0' COMMENT 'Со скидкой',
  `status` tinyint DEFAULT '0' COMMENT 'Статус оплаты',
  `payment_type` tinyint DEFAULT NULL COMMENT 'Тип оплаты',
  `external_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'ID транзакции в платёжной системе',
  `created_at` datetime DEFAULT NULL COMMENT 'Дата создания',
  `created_admin_id` int UNSIGNED DEFAULT NULL COMMENT 'Кто добавил',
  `paid_at` datetime DEFAULT NULL COMMENT 'Дата оплаты',
  `paid_admin_id` int UNSIGNED DEFAULT NULL COMMENT 'Кто отметил оплаченным'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `debt`
--

CREATE TABLE `debt` (
  `user_id` int UNSIGNED NOT NULL COMMENT 'ID должника',
  `group_id` int UNSIGNED NOT NULL COMMENT 'Группа',
  `amount` float NOT NULL COMMENT 'Сумма задолженности',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Когда появился долг'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `email_queue`
--

CREATE TABLE `email_queue` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID записи',
  `template_html` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'HTML-шаблон',
  `template_text` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Текстовый шаблон',
  `params` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Параметры для передачи в шаблон',
  `sender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Отправитель',
  `recipient` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Получатель',
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Тема',
  `state` tinyint UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Статус отправки',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата добавления',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Дата изменения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `errors`
--

CREATE TABLE `errors` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID',
  `module` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Место ошибки',
  `content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Содержимое ошибки',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Время возникновения ошибки'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID записи',
  `group_id` int UNSIGNED NOT NULL COMMENT 'ID группы',
  `event_date` datetime NOT NULL COMMENT 'Дата занятия',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Статус занятия'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `event_member`
--

CREATE TABLE `event_member` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID записи',
  `group_pupil_id` int UNSIGNED NOT NULL COMMENT 'ID ученика в группе',
  `event_id` int UNSIGNED NOT NULL COMMENT 'ID занятия',
  `status` tinyint UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Статус присутствия',
  `mark` tinyint DEFAULT NULL COMMENT 'Оценка',
  `mark_homework` tinyint UNSIGNED DEFAULT NULL,
  `attendance_notification_sent` tinyint DEFAULT '0',
  `mark_notification_sent` tinyint DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `gift_card`
--

CREATE TABLE `gift_card` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID',
  `name` varchar(127) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Название',
  `amount` int UNSIGNED NOT NULL COMMENT 'Номинал',
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Проверочный код',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT 'Статус',
  `customer_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'ФИО покупателя',
  `customer_phone` varchar(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Телефон покупателя',
  `customer_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'E-mail покупателя',
  `additional` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Дополнительная информация',
  `created_at` datetime NOT NULL COMMENT 'Дата добавления',
  `paid_at` datetime DEFAULT NULL COMMENT 'Дата оплаты',
  `used_at` datetime DEFAULT NULL COMMENT 'Дата активации'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gift_card_type`
--

CREATE TABLE `gift_card_type` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID',
  `name` varchar(127) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Название',
  `amount` int UNSIGNED NOT NULL COMMENT 'Номинал',
  `email_html` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Письмо HTML',
  `email_text` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Письмо текстовое',
  `active` tinyint NOT NULL DEFAULT '1' COMMENT 'Доступна для покупки'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE `group` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID группы',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Название группы',
  `legal_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Официальное название (для договора)',
  `type_id` int UNSIGNED DEFAULT NULL COMMENT 'Тип группы',
  `subject_id` int UNSIGNED NOT NULL COMMENT 'ID предмета',
  `teacher_id` int UNSIGNED DEFAULT NULL COMMENT 'ID учителя',
  `schedule` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'График занятий группы',
  `lesson_price` int UNSIGNED NOT NULL COMMENT 'Цена занятия',
  `lesson_price_discount` int UNSIGNED DEFAULT NULL COMMENT 'Цена занятия со скидкой',
  `lesson_duration` int UNSIGNED DEFAULT NULL COMMENT 'прододжительность занятия',
  `teacher_rate` float NOT NULL DEFAULT '0' COMMENT 'Процент начислений зарплаты учителю',
  `room_number` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Номер кабинета',
  `active` tinyint UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Занимается ли группа',
  `date_start` date DEFAULT NULL COMMENT 'Дата начала занятий',
  `date_end` date DEFAULT NULL COMMENT 'Дата завершения занятий'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `group_note`
--

CREATE TABLE `group_note` (
  `id` int UNSIGNED NOT NULL,
  `group_id` int UNSIGNED NOT NULL,
  `teacher_id` int UNSIGNED NOT NULL,
  `topic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `group_param`
--

CREATE TABLE `group_param` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID записи',
  `group_id` int UNSIGNED NOT NULL COMMENT 'Группа',
  `year` smallint UNSIGNED NOT NULL COMMENT 'год',
  `month` tinyint UNSIGNED NOT NULL COMMENT 'месяц',
  `lesson_price` int UNSIGNED NOT NULL COMMENT 'Цена занятия',
  `lesson_price_discount` int UNSIGNED DEFAULT NULL COMMENT 'Цена занятия со скидкой',
  `schedule` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'График занятий группы ',
  `teacher_id` int UNSIGNED NOT NULL COMMENT 'Учитель',
  `teacher_rate` float NOT NULL COMMENT 'Процент учителю',
  `teacher_salary` int UNSIGNED DEFAULT NULL COMMENT 'Зарплата учителя'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `group_pupil`
--

CREATE TABLE `group_pupil` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID записи',
  `user_id` int UNSIGNED NOT NULL COMMENT 'ID ученика',
  `group_id` int UNSIGNED NOT NULL COMMENT 'ID группы',
  `active` tinyint NOT NULL DEFAULT '1' COMMENT 'Активен ли студент',
  `date_start` date DEFAULT NULL COMMENT 'Дата начала занятий в группу',
  `date_end` date DEFAULT NULL COMMENT 'Дата завершения занятий в группе',
  `moved` tinyint NOT NULL DEFAULT '0' COMMENT 'Перешёл в другую группу',
  `end_reason` tinyint UNSIGNED DEFAULT NULL,
  `comment` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `date_charge_till` timestamp NULL DEFAULT NULL COMMENT 'Стоимость списана до этой даты',
  `paid_lessons` int NOT NULL DEFAULT '0' COMMENT 'Сколько оплаченных занятий осталось'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `group_type`
--

CREATE TABLE `group_type` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `high_school`
--

CREATE TABLE `high_school` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID ВУЗа',
  `type` tinyint NOT NULL COMMENT 'Тип учебного заведения',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Название учебного заведения',
  `name_short` varchar(127) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Аббревиатура',
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Фото',
  `short_description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Краткое описание',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Полное описание',
  `page_order` int UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Порядок отображения на странице',
  `active` tinyint NOT NULL DEFAULT '1' COMMENT 'Показывать'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `language_id` tinyint UNSIGNED NOT NULL,
  `language_code` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `language_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `language_active` tinyint UNSIGNED NOT NULL DEFAULT '1',
  `language_default` tinyint UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `id` tinyint UNSIGNED NOT NULL,
  `controller` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `action` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `url_prefix` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Префикс URL',
  `field_for_url` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Поле, которое использовать для генерации URL',
  `field_for_title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Поле, из которого скопировать Title',
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_blog`
--

CREATE TABLE `module_blog` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID статьи',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Заголовок',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Картинка',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Контент',
  `webpage_id` int UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `active` tinyint UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Активен',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата публикакции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `module_feedback`
--

CREATE TABLE `module_feedback` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID сообщения',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Имя пользователя',
  `contact` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Как с ним связаться',
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Сообщение',
  `ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'IP адрес отправителя',
  `status` enum('new','read','completed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'new' COMMENT 'Статус',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_news`
--

CREATE TABLE `module_news` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID новости',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Заголовок',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Картинка',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Контент',
  `webpage_id` int UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `active` tinyint UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Активен',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата публикакции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `module_order`
--

CREATE TABLE `module_order` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID',
  `source` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Источник заявки',
  `subject` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Предмет',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Имя',
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Телефон',
  `tg_login` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'E-mail',
  `status` enum('unread','read','done','problem') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'unread' COMMENT 'Статус заявки',
  `user_comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Комментарии от заказчика',
  `admin_comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Комментарии админа',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата подачи'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_order_subject`
--

CREATE TABLE `module_order_subject` (
  `name` varchar(127) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Название предмета'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_page`
--

CREATE TABLE `module_page` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Заголовок',
  `content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Содержимое',
  `webpage_id` int UNSIGNED DEFAULT NULL COMMENT 'ID webpage',
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'активна',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_promotions`
--

CREATE TABLE `module_promotions` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID акции',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Заголовок',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Картинка',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Контент',
  `webpage_id` int UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `active` tinyint UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Активен',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата акции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `module_review`
--

CREATE TABLE `module_review` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID отзыва',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Имя автора',
  `age` tinyint DEFAULT NULL COMMENT 'Возраст автора',
  `message` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Текст отзыва',
  `status` enum('new','approved') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'new' COMMENT 'Статус отзыва',
  `ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'IP адрес отправителя',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_subject`
--

CREATE TABLE `module_subject` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID предмета',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Название предмета',
  `category_id` int UNSIGNED DEFAULT NULL COMMENT 'ID группы',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Картинка',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Тизер',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Контент',
  `webpage_id` int UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `bitrix_name` varchar(127) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Bitrix name',
  `active` tinyint UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Активен'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `module_subject_category`
--

CREATE TABLE `module_subject_category` (
  `id` int UNSIGNED NOT NULL COMMENT 'id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Название группы',
  `webpage_id` int UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `page_order` int DEFAULT '0' COMMENT 'Порядок отображения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `notify`
--

CREATE TABLE `notify` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID',
  `user_id` int UNSIGNED NOT NULL COMMENT 'ID студента',
  `group_id` int UNSIGNED DEFAULT NULL COMMENT 'Группа',
  `template_id` int UNSIGNED NOT NULL COMMENT 'ID шаблона',
  `params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Параметры для сообщения',
  `status` int UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Статус отправки сообщения',
  `created_at` datetime NOT NULL COMMENT 'Дата создания',
  `sent_at` datetime DEFAULT NULL COMMENT 'Дата успешной отправки',
  `attempts` int UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Попыток отправки'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID записи',
  `user_id` int UNSIGNED NOT NULL COMMENT 'ID студента',
  `admin_id` int UNSIGNED DEFAULT NULL COMMENT 'ID админа',
  `group_id` int UNSIGNED DEFAULT NULL COMMENT 'Группа',
  `amount` int NOT NULL COMMENT 'Сумма',
  `discount` tinyint DEFAULT '0' COMMENT 'Скидочный платёж',
  `comment` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Комментарий',
  `contract_id` int UNSIGNED DEFAULT NULL COMMENT 'ID договора',
  `used_payment_id` int UNSIGNED DEFAULT NULL COMMENT 'ID использованного при списании платежа',
  `event_member_id` int UNSIGNED DEFAULT NULL COMMENT 'ID занятия',
  `cash_received` tinyint UNSIGNED DEFAULT '1' COMMENT 'Получены ли физически денежные средства',
  `bitrix_sync_status` tinyint NOT NULL DEFAULT '0' COMMENT 'Статус синхронизации с Bitrix',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата операции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `payment_link`
--

CREATE TABLE `payment_link` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID',
  `hash_key` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'ключ',
  `user_id` int UNSIGNED NOT NULL COMMENT 'Студент',
  `group_id` int UNSIGNED NOT NULL COMMENT 'Группа'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_callback_query`
--

CREATE TABLE `ptg_callback_query` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this query',
  `user_id` bigint DEFAULT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint UNSIGNED DEFAULT NULL COMMENT 'Unique message identifier',
  `inline_message_id` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the message sent via the bot in inline mode, that originated the query',
  `chat_instance` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Global identifier, uniquely corresponding to the chat to which the message with the callback button was sent',
  `data` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Data associated with the callback button',
  `game_short_name` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Short name of a Game to be returned, serves as the unique identifier for the game',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_chat`
--

CREATE TABLE `ptg_chat` (
  `id` bigint NOT NULL COMMENT 'Unique identifier for this chat',
  `type` enum('private','group','supergroup','channel') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Type of chat, can be either private, group, supergroup or channel',
  `title` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT '' COMMENT 'Title, for supergroups, channels and group chats',
  `username` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Username, for private chats, supergroups and channels if available',
  `first_name` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'First name of the other party in a private chat',
  `last_name` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Last name of the other party in a private chat',
  `all_members_are_administrators` tinyint(1) DEFAULT '0' COMMENT 'True if a all members of this group are admins',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update',
  `old_id` bigint DEFAULT NULL COMMENT 'Unique chat identifier, this is filled when a group is converted to a supergroup'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_chat_join_request`
--

CREATE TABLE `ptg_chat_join_request` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `chat_id` bigint NOT NULL COMMENT 'Chat to which the request was sent',
  `user_id` bigint NOT NULL COMMENT 'User that sent the join request',
  `date` timestamp NOT NULL COMMENT 'Date the request was sent in Unix time',
  `bio` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Optional. Bio of the user',
  `invite_link` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Optional. Chat invite link that was used by the user to send the join request',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_chat_member_updated`
--

CREATE TABLE `ptg_chat_member_updated` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `chat_id` bigint NOT NULL COMMENT 'Chat the user belongs to',
  `user_id` bigint NOT NULL COMMENT 'Performer of the action, which resulted in the change',
  `date` timestamp NOT NULL COMMENT 'Date the change was done in Unix time',
  `old_chat_member` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Previous information about the chat member',
  `new_chat_member` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'New information about the chat member',
  `invite_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Chat invite link, which was used by the user to join the chat; for joining by invite link events only',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_chosen_inline_result`
--

CREATE TABLE `ptg_chosen_inline_result` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `result_id` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'The unique identifier for the result that was chosen',
  `user_id` bigint DEFAULT NULL COMMENT 'The user that chose the result',
  `location` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Sender location, only for bots that require user location',
  `inline_message_id` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the sent inline message',
  `query` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'The query that was used to obtain the result',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_conversation`
--

CREATE TABLE `ptg_conversation` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `user_id` bigint DEFAULT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint DEFAULT NULL COMMENT 'Unique user or chat identifier',
  `status` enum('active','cancelled','stopped') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active' COMMENT 'Conversation state',
  `command` varchar(160) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT '' COMMENT 'Default command to execute',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Data stored from command',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_edited_message`
--

CREATE TABLE `ptg_edited_message` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `chat_id` bigint DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint UNSIGNED DEFAULT NULL COMMENT 'Unique message identifier',
  `user_id` bigint DEFAULT NULL COMMENT 'Unique user identifier',
  `edit_date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was edited in timestamp format',
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, the actual UTF-8 text of the message max message length 4096 char utf8',
  `entities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, special entities like usernames, URLs, bot commands, etc. that appear in the text',
  `caption` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For message with caption, the actual UTF-8 text of the caption'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_inline_query`
--

CREATE TABLE `ptg_inline_query` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this query',
  `user_id` bigint DEFAULT NULL COMMENT 'Unique user identifier',
  `location` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Location of the user',
  `query` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Text of the query',
  `offset` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Offset of the result',
  `chat_type` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Optional. Type of the chat, from which the inline query was sent.',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_message`
--

CREATE TABLE `ptg_message` (
  `chat_id` bigint NOT NULL COMMENT 'Unique chat identifier',
  `sender_chat_id` bigint DEFAULT NULL COMMENT 'Sender of the message, sent on behalf of a chat',
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique message identifier',
  `user_id` bigint DEFAULT NULL COMMENT 'Unique user identifier',
  `date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was sent in timestamp format',
  `forward_from` bigint DEFAULT NULL COMMENT 'Unique user identifier, sender of the original message',
  `forward_from_chat` bigint DEFAULT NULL COMMENT 'Unique chat identifier, chat the original message belongs to',
  `forward_from_message_id` bigint DEFAULT NULL COMMENT 'Unique chat identifier of the original message in the channel',
  `forward_signature` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For messages forwarded from channels, signature of the post author if present',
  `forward_sender_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Sender''s name for messages forwarded from users who disallow adding a link to their account in forwarded messages',
  `forward_date` timestamp NULL DEFAULT NULL COMMENT 'date the original message was sent in timestamp format',
  `is_automatic_forward` tinyint(1) DEFAULT '0' COMMENT 'True, if the message is a channel post that was automatically forwarded to the connected discussion group',
  `reply_to_chat` bigint DEFAULT NULL COMMENT 'Unique chat identifier',
  `reply_to_message` bigint UNSIGNED DEFAULT NULL COMMENT 'Message that this message is reply to',
  `via_bot` bigint DEFAULT NULL COMMENT 'Optional. Bot through which the message was sent',
  `edit_date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was last edited in Unix time',
  `has_protected_content` tinyint(1) DEFAULT '0' COMMENT 'True, if the message can''t be forwarded',
  `media_group_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'The unique identifier of a media message group this message belongs to',
  `author_signature` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Signature of the post author for messages in channels',
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, the actual UTF-8 text of the message max message length 4096 char utf8mb4',
  `entities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, special entities like usernames, URLs, bot commands, etc. that appear in the text',
  `caption_entities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For messages with a caption, special entities like usernames, URLs, bot commands, etc. that appear in the caption',
  `audio` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Audio object. Message is an audio file, information about the file',
  `document` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Document object. Message is a general file, information about the file',
  `animation` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Message is an animation, information about the animation',
  `game` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Game object. Message is a game, information about the game',
  `photo` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Array of PhotoSize objects. Message is a photo, available sizes of the photo',
  `sticker` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Sticker object. Message is a sticker, information about the sticker',
  `video` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Video object. Message is a video, information about the video',
  `voice` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Voice Object. Message is a Voice, information about the Voice',
  `video_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'VoiceNote Object. Message is a Video Note, information about the Video Note',
  `caption` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For message with caption, the actual UTF-8 text of the caption',
  `contact` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Contact object. Message is a shared contact, information about the contact',
  `location` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Location object. Message is a shared location, information about the location',
  `venue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Venue object. Message is a Venue, information about the Venue',
  `poll` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Poll object. Message is a native poll, information about the poll',
  `dice` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Message is a dice with random value from 1 to 6',
  `new_chat_members` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'List of unique user identifiers, new member(s) were added to the group, information about them (one of these members may be the bot itself)',
  `left_chat_member` bigint DEFAULT NULL COMMENT 'Unique user identifier, a member was removed from the group, information about them (this member may be the bot itself)',
  `new_chat_title` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'A chat title was changed to this value',
  `new_chat_photo` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Array of PhotoSize objects. A chat photo was change to this value',
  `delete_chat_photo` tinyint(1) DEFAULT '0' COMMENT 'Informs that the chat photo was deleted',
  `group_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the group has been created',
  `supergroup_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the supergroup has been created',
  `channel_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the channel chat has been created',
  `message_auto_delete_timer_changed` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'MessageAutoDeleteTimerChanged object. Message is a service message: auto-delete timer settings changed in the chat',
  `migrate_to_chat_id` bigint DEFAULT NULL COMMENT 'Migrate to chat identifier. The group has been migrated to a supergroup with the specified identifier',
  `migrate_from_chat_id` bigint DEFAULT NULL COMMENT 'Migrate from chat identifier. The supergroup has been migrated from a group with the specified identifier',
  `pinned_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Message object. Specified message was pinned',
  `invoice` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Message is an invoice for a payment, information about the invoice',
  `successful_payment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Message is a service message about a successful payment, information about the payment',
  `connected_website` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'The domain name of the website on which the user has logged in.',
  `passport_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Telegram Passport data',
  `proximity_alert_triggered` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Service message. A user in the chat triggered another user''s proximity alert while sharing Live Location.',
  `voice_chat_scheduled` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'VoiceChatScheduled object. Message is a service message: voice chat scheduled',
  `voice_chat_started` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'VoiceChatStarted object. Message is a service message: voice chat started',
  `voice_chat_ended` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'VoiceChatEnded object. Message is a service message: voice chat ended',
  `voice_chat_participants_invited` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'VoiceChatParticipantsInvited object. Message is a service message: new participants invited to a voice chat',
  `reply_markup` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Inline keyboard attached to the message'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_poll`
--

CREATE TABLE `ptg_poll` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique poll identifier',
  `question` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Poll question',
  `options` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'List of poll options',
  `total_voter_count` int UNSIGNED DEFAULT NULL COMMENT 'Total number of users that voted in the poll',
  `is_closed` tinyint(1) DEFAULT '0' COMMENT 'True, if the poll is closed',
  `is_anonymous` tinyint(1) DEFAULT '1' COMMENT 'True, if the poll is anonymous',
  `type` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Poll type, currently can be “regular” or “quiz”',
  `allows_multiple_answers` tinyint(1) DEFAULT '0' COMMENT 'True, if the poll allows multiple answers',
  `correct_option_id` int UNSIGNED DEFAULT NULL COMMENT '0-based identifier of the correct answer option. Available only for polls in the quiz mode, which are closed, or was sent (not forwarded) by the bot or to the private chat with the bot.',
  `explanation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Text that is shown when a user chooses an incorrect answer or taps on the lamp icon in a quiz-style poll, 0-200 characters',
  `explanation_entities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Special entities like usernames, URLs, bot commands, etc. that appear in the explanation',
  `open_period` int UNSIGNED DEFAULT NULL COMMENT 'Amount of time in seconds the poll will be active after creation',
  `close_date` timestamp NULL DEFAULT NULL COMMENT 'Point in time (Unix timestamp) when the poll will be automatically closed',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_poll_answer`
--

CREATE TABLE `ptg_poll_answer` (
  `poll_id` bigint UNSIGNED NOT NULL COMMENT 'Unique poll identifier',
  `user_id` bigint NOT NULL COMMENT 'The user, who changed the answer to the poll',
  `option_ids` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT '0-based identifiers of answer options, chosen by the user. May be empty if the user retracted their vote.',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_pre_checkout_query`
--

CREATE TABLE `ptg_pre_checkout_query` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique query identifier',
  `user_id` bigint DEFAULT NULL COMMENT 'User who sent the query',
  `currency` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Three-letter ISO 4217 currency code',
  `total_amount` bigint DEFAULT NULL COMMENT 'Total price in the smallest units of the currency',
  `invoice_payload` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Bot specified invoice payload',
  `shipping_option_id` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the shipping option chosen by the user',
  `order_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Order info provided by the user',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_request_limiter`
--

CREATE TABLE `ptg_request_limiter` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `chat_id` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Unique chat identifier',
  `inline_message_id` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the sent inline message',
  `method` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Request method',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_shipping_query`
--

CREATE TABLE `ptg_shipping_query` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique query identifier',
  `user_id` bigint DEFAULT NULL COMMENT 'User who sent the query',
  `invoice_payload` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Bot specified invoice payload',
  `shipping_address` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'User specified shipping address',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_telegram_update`
--

CREATE TABLE `ptg_telegram_update` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Update''s unique identifier',
  `chat_id` bigint DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New incoming message of any kind - text, photo, sticker, etc.',
  `edited_message_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New version of a message that is known to the bot and was edited',
  `channel_post_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New incoming channel post of any kind - text, photo, sticker, etc.',
  `edited_channel_post_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New version of a channel post that is known to the bot and was edited',
  `inline_query_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New incoming inline query',
  `chosen_inline_result_id` bigint UNSIGNED DEFAULT NULL COMMENT 'The result of an inline query that was chosen by a user and sent to their chat partner',
  `callback_query_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New incoming callback query',
  `shipping_query_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New incoming shipping query. Only for invoices with flexible price',
  `pre_checkout_query_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New incoming pre-checkout query. Contains full information about checkout',
  `poll_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New poll state. Bots receive only updates about polls, which are sent or stopped by the bot',
  `poll_answer_poll_id` bigint UNSIGNED DEFAULT NULL COMMENT 'A user changed their answer in a non-anonymous poll. Bots receive new votes only in polls that were sent by the bot itself.',
  `my_chat_member_updated_id` bigint UNSIGNED DEFAULT NULL COMMENT 'The bot''s chat member status was updated in a chat. For private chats, this update is received only when the bot is blocked or unblocked by the user.',
  `chat_member_updated_id` bigint UNSIGNED DEFAULT NULL COMMENT 'A chat member''s status was updated in a chat. The bot must be an administrator in the chat and must explicitly specify “chat_member” in the list of allowed_updates to receive these updates.',
  `chat_join_request_id` bigint UNSIGNED DEFAULT NULL COMMENT 'A request to join the chat has been sent'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_user`
--

CREATE TABLE `ptg_user` (
  `id` bigint NOT NULL COMMENT 'Unique identifier for this user or bot',
  `is_bot` tinyint(1) DEFAULT '0' COMMENT 'True, if this user is a bot',
  `first_name` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'User''s or bot''s first name',
  `last_name` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'User''s or bot''s last name',
  `username` char(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'User''s or bot''s username',
  `language_code` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'IETF language tag of the user''s language',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ptg_user_chat`
--

CREATE TABLE `ptg_user_chat` (
  `user_id` bigint NOT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint NOT NULL COMMENT 'Unique user or chat identifier'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID записи',
  `quiz_id` int UNSIGNED NOT NULL COMMENT 'ID теста',
  `parent_id` int UNSIGNED DEFAULT NULL COMMENT 'Вопрос',
  `content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Текст вопроса/ответа',
  `is_right` tinyint UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Правильный ответ',
  `sort_order` int UNSIGNED DEFAULT NULL COMMENT 'Порядок вопроса'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID теста',
  `subject_id` int UNSIGNED NOT NULL COMMENT 'ID предмета',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Название',
  `page_order` int UNSIGNED DEFAULT NULL COMMENT 'Порядок отображения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_result`
--

CREATE TABLE `quiz_result` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID записи',
  `hash` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'ключ записи',
  `student_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Имя студента',
  `subject_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Название предмета',
  `quiz_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Название теста',
  `questions_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Вопросы',
  `answers_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Ответы',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Время начала теста',
  `finished_at` timestamp NULL DEFAULT NULL COMMENT 'Время завершения теста'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID учителя',
  `name` varchar(127) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'ФИО',
  `phone` char(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Телефон',
  `birthday` date DEFAULT NULL COMMENT 'День рождения',
  `contract_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Как представлять учителя',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Описание',
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Фото',
  `webpage_id` int UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `page_visibility` tinyint NOT NULL DEFAULT '1' COMMENT 'Отображать на странице учителей',
  `page_order` int NOT NULL DEFAULT '0' COMMENT 'Порядок отображения на странице учителей',
  `active` tinyint UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Работает ли учитель'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_subject`
--

CREATE TABLE `teacher_subject` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID записи',
  `teacher_id` int UNSIGNED NOT NULL COMMENT 'ID учителя',
  `subject_id` int UNSIGNED NOT NULL COMMENT 'ID предмета'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `tg_callback_query`
--

CREATE TABLE `tg_callback_query` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this query',
  `user_id` bigint DEFAULT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint UNSIGNED DEFAULT NULL COMMENT 'Unique message identifier',
  `inline_message_id` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the message sent via the bot in inline mode, that originated the query',
  `chat_instance` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Global identifier, uniquely corresponding to the chat to which the message with the callback button was sent',
  `data` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Data associated with the callback button',
  `game_short_name` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Short name of a Game to be returned, serves as the unique identifier for the game',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_chat`
--

CREATE TABLE `tg_chat` (
  `id` bigint NOT NULL COMMENT 'Unique identifier for this chat',
  `type` enum('private','group','supergroup','channel') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Type of chat, can be either private, group, supergroup or channel',
  `title` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT '' COMMENT 'Title, for supergroups, channels and group chats',
  `username` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Username, for private chats, supergroups and channels if available',
  `first_name` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'First name of the other party in a private chat',
  `last_name` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Last name of the other party in a private chat',
  `all_members_are_administrators` tinyint(1) DEFAULT '0' COMMENT 'True if a all members of this group are admins',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update',
  `old_id` bigint DEFAULT NULL COMMENT 'Unique chat identifier, this is filled when a group is converted to a supergroup'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_chat_join_request`
--

CREATE TABLE `tg_chat_join_request` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `chat_id` bigint NOT NULL COMMENT 'Chat to which the request was sent',
  `user_id` bigint NOT NULL COMMENT 'User that sent the join request',
  `date` timestamp NOT NULL COMMENT 'Date the request was sent in Unix time',
  `bio` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Optional. Bio of the user',
  `invite_link` text COLLATE utf8mb4_unicode_520_ci COMMENT 'Optional. Chat invite link that was used by the user to send the join request',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_chat_member_updated`
--

CREATE TABLE `tg_chat_member_updated` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `chat_id` bigint NOT NULL COMMENT 'Chat the user belongs to',
  `user_id` bigint NOT NULL COMMENT 'Performer of the action, which resulted in the change',
  `date` timestamp NOT NULL COMMENT 'Date the change was done in Unix time',
  `old_chat_member` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Previous information about the chat member',
  `new_chat_member` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'New information about the chat member',
  `invite_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Chat invite link, which was used by the user to join the chat; for joining by invite link events only',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_chosen_inline_result`
--

CREATE TABLE `tg_chosen_inline_result` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `result_id` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'The unique identifier for the result that was chosen',
  `user_id` bigint DEFAULT NULL COMMENT 'The user that chose the result',
  `location` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Sender location, only for bots that require user location',
  `inline_message_id` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the sent inline message',
  `query` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'The query that was used to obtain the result',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_conversation`
--

CREATE TABLE `tg_conversation` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `user_id` bigint DEFAULT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint DEFAULT NULL COMMENT 'Unique user or chat identifier',
  `status` enum('active','cancelled','stopped') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active' COMMENT 'Conversation state',
  `command` varchar(160) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT '' COMMENT 'Default command to execute',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Data stored from command',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_edited_message`
--

CREATE TABLE `tg_edited_message` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `chat_id` bigint DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint UNSIGNED DEFAULT NULL COMMENT 'Unique message identifier',
  `user_id` bigint DEFAULT NULL COMMENT 'Unique user identifier',
  `edit_date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was edited in timestamp format',
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, the actual UTF-8 text of the message max message length 4096 char utf8',
  `entities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, special entities like usernames, URLs, bot commands, etc. that appear in the text',
  `caption` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For message with caption, the actual UTF-8 text of the caption'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_inline_query`
--

CREATE TABLE `tg_inline_query` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this query',
  `user_id` bigint DEFAULT NULL COMMENT 'Unique user identifier',
  `location` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Location of the user',
  `query` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Text of the query',
  `offset` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Offset of the result',
  `chat_type` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Optional. Type of the chat, from which the inline query was sent.',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_message`
--

CREATE TABLE `tg_message` (
  `chat_id` bigint NOT NULL COMMENT 'Unique chat identifier',
  `sender_chat_id` bigint DEFAULT NULL COMMENT 'Sender of the message, sent on behalf of a chat',
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique message identifier',
  `user_id` bigint DEFAULT NULL COMMENT 'Unique user identifier',
  `date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was sent in timestamp format',
  `forward_from` bigint DEFAULT NULL COMMENT 'Unique user identifier, sender of the original message',
  `forward_from_chat` bigint DEFAULT NULL COMMENT 'Unique chat identifier, chat the original message belongs to',
  `forward_from_message_id` bigint DEFAULT NULL COMMENT 'Unique chat identifier of the original message in the channel',
  `forward_signature` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For messages forwarded from channels, signature of the post author if present',
  `forward_sender_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Sender''s name for messages forwarded from users who disallow adding a link to their account in forwarded messages',
  `forward_date` timestamp NULL DEFAULT NULL COMMENT 'date the original message was sent in timestamp format',
  `is_automatic_forward` tinyint(1) DEFAULT '0' COMMENT 'True, if the message is a channel post that was automatically forwarded to the connected discussion group',
  `reply_to_chat` bigint DEFAULT NULL COMMENT 'Unique chat identifier',
  `reply_to_message` bigint UNSIGNED DEFAULT NULL COMMENT 'Message that this message is reply to',
  `via_bot` bigint DEFAULT NULL COMMENT 'Optional. Bot through which the message was sent',
  `edit_date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was last edited in Unix time',
  `has_protected_content` tinyint(1) DEFAULT '0' COMMENT 'True, if the message can''t be forwarded',
  `media_group_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'The unique identifier of a media message group this message belongs to',
  `author_signature` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Signature of the post author for messages in channels',
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, the actual UTF-8 text of the message max message length 4096 char utf8mb4',
  `entities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For text messages, special entities like usernames, URLs, bot commands, etc. that appear in the text',
  `caption_entities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For messages with a caption, special entities like usernames, URLs, bot commands, etc. that appear in the caption',
  `audio` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Audio object. Message is an audio file, information about the file',
  `document` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Document object. Message is a general file, information about the file',
  `animation` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Message is an animation, information about the animation',
  `game` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Game object. Message is a game, information about the game',
  `photo` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Array of PhotoSize objects. Message is a photo, available sizes of the photo',
  `sticker` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Sticker object. Message is a sticker, information about the sticker',
  `video` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Video object. Message is a video, information about the video',
  `voice` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Voice Object. Message is a Voice, information about the Voice',
  `video_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'VoiceNote Object. Message is a Video Note, information about the Video Note',
  `caption` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'For message with caption, the actual UTF-8 text of the caption',
  `contact` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Contact object. Message is a shared contact, information about the contact',
  `location` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Location object. Message is a shared location, information about the location',
  `venue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Venue object. Message is a Venue, information about the Venue',
  `poll` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Poll object. Message is a native poll, information about the poll',
  `dice` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Message is a dice with random value from 1 to 6',
  `new_chat_members` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'List of unique user identifiers, new member(s) were added to the group, information about them (one of these members may be the bot itself)',
  `left_chat_member` bigint DEFAULT NULL COMMENT 'Unique user identifier, a member was removed from the group, information about them (this member may be the bot itself)',
  `new_chat_title` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'A chat title was changed to this value',
  `new_chat_photo` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Array of PhotoSize objects. A chat photo was change to this value',
  `delete_chat_photo` tinyint(1) DEFAULT '0' COMMENT 'Informs that the chat photo was deleted',
  `group_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the group has been created',
  `supergroup_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the supergroup has been created',
  `channel_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the channel chat has been created',
  `message_auto_delete_timer_changed` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'MessageAutoDeleteTimerChanged object. Message is a service message: auto-delete timer settings changed in the chat',
  `migrate_to_chat_id` bigint DEFAULT NULL COMMENT 'Migrate to chat identifier. The group has been migrated to a supergroup with the specified identifier',
  `migrate_from_chat_id` bigint DEFAULT NULL COMMENT 'Migrate from chat identifier. The supergroup has been migrated from a group with the specified identifier',
  `pinned_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Message object. Specified message was pinned',
  `invoice` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Message is an invoice for a payment, information about the invoice',
  `successful_payment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Message is a service message about a successful payment, information about the payment',
  `connected_website` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'The domain name of the website on which the user has logged in.',
  `passport_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Telegram Passport data',
  `proximity_alert_triggered` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Service message. A user in the chat triggered another user''s proximity alert while sharing Live Location.',
  `voice_chat_scheduled` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'VoiceChatScheduled object. Message is a service message: voice chat scheduled',
  `voice_chat_started` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'VoiceChatStarted object. Message is a service message: voice chat started',
  `voice_chat_ended` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'VoiceChatEnded object. Message is a service message: voice chat ended',
  `voice_chat_participants_invited` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'VoiceChatParticipantsInvited object. Message is a service message: new participants invited to a voice chat',
  `reply_markup` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Inline keyboard attached to the message'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_poll`
--

CREATE TABLE `tg_poll` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique poll identifier',
  `question` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Poll question',
  `options` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'List of poll options',
  `total_voter_count` int UNSIGNED DEFAULT NULL COMMENT 'Total number of users that voted in the poll',
  `is_closed` tinyint(1) DEFAULT '0' COMMENT 'True, if the poll is closed',
  `is_anonymous` tinyint(1) DEFAULT '1' COMMENT 'True, if the poll is anonymous',
  `type` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Poll type, currently can be “regular” or “quiz”',
  `allows_multiple_answers` tinyint(1) DEFAULT '0' COMMENT 'True, if the poll allows multiple answers',
  `correct_option_id` int UNSIGNED DEFAULT NULL COMMENT '0-based identifier of the correct answer option. Available only for polls in the quiz mode, which are closed, or was sent (not forwarded) by the bot or to the private chat with the bot.',
  `explanation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Text that is shown when a user chooses an incorrect answer or taps on the lamp icon in a quiz-style poll, 0-200 characters',
  `explanation_entities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Special entities like usernames, URLs, bot commands, etc. that appear in the explanation',
  `open_period` int UNSIGNED DEFAULT NULL COMMENT 'Amount of time in seconds the poll will be active after creation',
  `close_date` timestamp NULL DEFAULT NULL COMMENT 'Point in time (Unix timestamp) when the poll will be automatically closed',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_poll_answer`
--

CREATE TABLE `tg_poll_answer` (
  `poll_id` bigint UNSIGNED NOT NULL COMMENT 'Unique poll identifier',
  `user_id` bigint NOT NULL COMMENT 'The user, who changed the answer to the poll',
  `option_ids` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT '0-based identifiers of answer options, chosen by the user. May be empty if the user retracted their vote.',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_pre_checkout_query`
--

CREATE TABLE `tg_pre_checkout_query` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique query identifier',
  `user_id` bigint DEFAULT NULL COMMENT 'User who sent the query',
  `currency` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Three-letter ISO 4217 currency code',
  `total_amount` bigint DEFAULT NULL COMMENT 'Total price in the smallest units of the currency',
  `invoice_payload` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Bot specified invoice payload',
  `shipping_option_id` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the shipping option chosen by the user',
  `order_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Order info provided by the user',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_request_limiter`
--

CREATE TABLE `tg_request_limiter` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique identifier for this entry',
  `chat_id` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Unique chat identifier',
  `inline_message_id` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Identifier of the sent inline message',
  `method` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Request method',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_shipping_query`
--

CREATE TABLE `tg_shipping_query` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Unique query identifier',
  `user_id` bigint DEFAULT NULL COMMENT 'User who sent the query',
  `invoice_payload` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'Bot specified invoice payload',
  `shipping_address` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'User specified shipping address',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_telegram_update`
--

CREATE TABLE `tg_telegram_update` (
  `id` bigint UNSIGNED NOT NULL COMMENT 'Update''s unique identifier',
  `chat_id` bigint DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New incoming message of any kind - text, photo, sticker, etc.',
  `edited_message_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New version of a message that is known to the bot and was edited',
  `channel_post_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New incoming channel post of any kind - text, photo, sticker, etc.',
  `edited_channel_post_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New version of a channel post that is known to the bot and was edited',
  `inline_query_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New incoming inline query',
  `chosen_inline_result_id` bigint UNSIGNED DEFAULT NULL COMMENT 'The result of an inline query that was chosen by a user and sent to their chat partner',
  `callback_query_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New incoming callback query',
  `shipping_query_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New incoming shipping query. Only for invoices with flexible price',
  `pre_checkout_query_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New incoming pre-checkout query. Contains full information about checkout',
  `poll_id` bigint UNSIGNED DEFAULT NULL COMMENT 'New poll state. Bots receive only updates about polls, which are sent or stopped by the bot',
  `poll_answer_poll_id` bigint UNSIGNED DEFAULT NULL COMMENT 'A user changed their answer in a non-anonymous poll. Bots receive new votes only in polls that were sent by the bot itself.',
  `my_chat_member_updated_id` bigint UNSIGNED DEFAULT NULL COMMENT 'The bot''s chat member status was updated in a chat. For private chats, this update is received only when the bot is blocked or unblocked by the user.',
  `chat_member_updated_id` bigint UNSIGNED DEFAULT NULL COMMENT 'A chat member''s status was updated in a chat. The bot must be an administrator in the chat and must explicitly specify “chat_member” in the list of allowed_updates to receive these updates.',
  `chat_join_request_id` bigint UNSIGNED DEFAULT NULL COMMENT 'A request to join the chat has been sent'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_user`
--

CREATE TABLE `tg_user` (
  `id` bigint NOT NULL COMMENT 'Unique identifier for this user or bot',
  `is_bot` tinyint(1) DEFAULT '0' COMMENT 'True, if this user is a bot',
  `first_name` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '' COMMENT 'User''s or bot''s first name',
  `last_name` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'User''s or bot''s last name',
  `username` char(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'User''s or bot''s username',
  `language_code` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'IETF language tag of the user''s language',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tg_user_chat`
--

CREATE TABLE `tg_user_chat` (
  `user_id` bigint NOT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint NOT NULL COMMENT 'Unique user or chat identifier'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tinified`
--

CREATE TABLE `tinified` (
  `fileName` varchar(127) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `checksum` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int UNSIGNED NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `name` varchar(127) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Имя пользователя',
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Заметки',
  `auth_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `password_reset_token` varchar(127) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `phone` char(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Телефон',
  `phone2` char(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Доп. телефон',
  `tg_chat_id` bigint DEFAULT NULL COMMENT 'Telegram chat ID',
  `tg_params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `bitrix_id` int UNSIGNED DEFAULT NULL COMMENT 'Bitrix ID',
  `status` smallint NOT NULL DEFAULT '10',
  `money` int NOT NULL DEFAULT '0' COMMENT 'Баланс',
  `role` tinyint NOT NULL COMMENT 'Уровень доступа пользователя',
  `individual` tinyint NOT NULL DEFAULT '1',
  `parent_id` int UNSIGNED DEFAULT NULL COMMENT 'Родитель',
  `teacher_id` int UNSIGNED DEFAULT NULL COMMENT 'ID учителя',
  `bitrix_sync_status` tinyint NOT NULL DEFAULT '0' COMMENT 'Статус синхронизации с Bitrix',
  `age_confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата создания',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Дата изменения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `user_call`
--

CREATE TABLE `user_call` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID',
  `user_id` int UNSIGNED NOT NULL COMMENT 'ID студента',
  `admin_id` int UNSIGNED NOT NULL COMMENT 'ID админа',
  `comment` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Комментарий',
  `created_at` datetime NOT NULL COMMENT 'Дата звонка'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `group_id` tinyint UNSIGNED NOT NULL,
  `group_name` varchar(127) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `group_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `group_active` tinyint UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `webpage`
--

CREATE TABLE `webpage` (
  `id` int UNSIGNED NOT NULL,
  `url` char(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `main` tinyint UNSIGNED DEFAULT NULL,
  `title` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `keywords` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `active` tinyint UNSIGNED NOT NULL DEFAULT '1',
  `module_id` tinyint UNSIGNED DEFAULT NULL,
  `record_id` int UNSIGNED DEFAULT NULL,
  `inrobots` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `welcome_lesson`
--

CREATE TABLE `welcome_lesson` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID записи',
  `user_id` int UNSIGNED NOT NULL COMMENT 'ID студента',
  `subject_id` int UNSIGNED DEFAULT NULL COMMENT 'ID предмета',
  `teacher_id` int UNSIGNED DEFAULT NULL COMMENT 'ID учителя',
  `group_id` int UNSIGNED DEFAULT NULL COMMENT 'ID группы',
  `lesson_date` datetime NOT NULL COMMENT 'Дата занятия',
  `status` tinyint DEFAULT NULL COMMENT 'Статус занятия',
  `deny_reason` tinyint UNSIGNED DEFAULT NULL,
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `bitrix_sync_status` tinyint NOT NULL DEFAULT '0' COMMENT 'Статус синхронизации с Bitrix',
  `created_by` int UNSIGNED DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `widget_html`
--

CREATE TABLE `widget_html` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `editor` tinyint NOT NULL DEFAULT '0' COMMENT 'Визуальный редактор'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `widget_menu`
--

CREATE TABLE `widget_menu` (
  `id` tinyint UNSIGNED NOT NULL COMMENT 'ID',
  `name` varchar(63) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'Название меню',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Заголовок меню',
  `language_id` tinyint UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Язык'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `widget_menu_item`
--

CREATE TABLE `widget_menu_item` (
  `id` int UNSIGNED NOT NULL COMMENT 'ID',
  `menu_id` tinyint UNSIGNED NOT NULL COMMENT 'Меню',
  `parent_id` int UNSIGNED DEFAULT NULL COMMENT 'Родительский пункт меню',
  `webpage_id` int UNSIGNED DEFAULT NULL COMMENT 'Ссылка на страницу сайта',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'URL',
  `title` varchar(127) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'Текст пункта меню',
  `active` tinyint UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Показывать или нет',
  `attr` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci COMMENT 'Доп параметры',
  `orderby` int UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Порядок'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci ROW_FORMAT=COMPACT;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `action`
--
ALTER TABLE `action`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `admin_id` (`admin_id`) USING BTREE,
  ADD KEY `user_id` (`user_id`) USING BTREE,
  ADD KEY `group_id` (`group_id`) USING BTREE;

--
-- Indexes for table `age_confirmation`
--
ALTER TABLE `age_confirmation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `age_confirmation_user_id_IDX` (`user_id`) USING BTREE;

--
-- Indexes for table `auth`
--
ALTER TABLE `auth`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auth_user_id_fk` (`user_id`);

--
-- Indexes for table `bot_mailing`
--
ALTER TABLE `bot_mailing`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `bot_push`
--
ALTER TABLE `bot_push`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `confirmation_code`
--
ALTER TABLE `confirmation_code`
  ADD PRIMARY KEY (`id`),
  ADD KEY `phone` (`phone`),
  ADD KEY `code` (`code`);

--
-- Indexes for table `consultation`
--
ALTER TABLE `consultation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_consultation_user` (`user_id`),
  ADD KEY `FK_consultation_module_subject` (`subject_id`),
  ADD KEY `FK_consultation_user_2` (`created_by`);

--
-- Indexes for table `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contract_number_uindex` (`number`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `contract_group_id_index` (`group_id`),
  ADD KEY `contract_created_user_id_fk` (`created_admin_id`),
  ADD KEY `contract_paid_user_id_fk` (`paid_admin_id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `debt`
--
ALTER TABLE `debt`
  ADD PRIMARY KEY (`user_id`,`group_id`),
  ADD KEY `group_id` (`group_id`);

--
-- Indexes for table `email_queue`
--
ALTER TABLE `email_queue`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `errors`
--
ALTER TABLE `errors`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `group_id` (`group_id`) USING BTREE;

--
-- Indexes for table `event_member`
--
ALTER TABLE `event_member`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `event_id` (`event_id`) USING BTREE,
  ADD KEY `group_pupil_id` (`group_pupil_id`);

--
-- Indexes for table `gift_card`
--
ALTER TABLE `gift_card`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `gift_card_type`
--
ALTER TABLE `gift_card_type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `active` (`active`);

--
-- Indexes for table `group`
--
ALTER TABLE `group`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `subject_id` (`subject_id`) USING BTREE,
  ADD KEY `teacher_id` (`teacher_id`) USING BTREE,
  ADD KEY `group_group_type_id_fk` (`type_id`);

--
-- Indexes for table `group_note`
--
ALTER TABLE `group_note`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_note_group_id_IDX` (`group_id`) USING BTREE,
  ADD KEY `group_note_teacher_id_IDX` (`teacher_id`) USING BTREE;

--
-- Indexes for table `group_param`
--
ALTER TABLE `group_param`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `group_id` (`group_id`,`year`,`month`) USING BTREE,
  ADD KEY `teacher_id` (`teacher_id`) USING BTREE;

--
-- Indexes for table `group_pupil`
--
ALTER TABLE `group_pupil`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `user_id` (`user_id`) USING BTREE,
  ADD KEY `group_id` (`group_id`) USING BTREE;

--
-- Indexes for table `group_type`
--
ALTER TABLE `group_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `high_school`
--
ALTER TABLE `high_school`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`language_id`) USING BTREE,
  ADD UNIQUE KEY `language_code` (`language_code`) USING BTREE;

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `module_ukey` (`controller`,`action`) USING BTREE;

--
-- Indexes for table `module_blog`
--
ALTER TABLE `module_blog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `module_blog_ibfk_3` (`webpage_id`) USING BTREE;

--
-- Indexes for table `module_feedback`
--
ALTER TABLE `module_feedback`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `module_news`
--
ALTER TABLE `module_news`
  ADD PRIMARY KEY (`id`),
  ADD KEY `module_news_ibfk_3` (`webpage_id`) USING BTREE;

--
-- Indexes for table `module_order`
--
ALTER TABLE `module_order`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `module_order_subject`
--
ALTER TABLE `module_order_subject`
  ADD PRIMARY KEY (`name`) USING BTREE;

--
-- Indexes for table `module_page`
--
ALTER TABLE `module_page`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `page_webpage_id` (`webpage_id`) USING BTREE;

--
-- Indexes for table `module_promotions`
--
ALTER TABLE `module_promotions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `module_promotions_ibfk_3` (`webpage_id`) USING BTREE;

--
-- Indexes for table `module_review`
--
ALTER TABLE `module_review`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `module_subject`
--
ALTER TABLE `module_subject`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `name` (`name`,`category_id`) USING BTREE,
  ADD KEY `category_id` (`category_id`) USING BTREE,
  ADD KEY `webpage_id` (`webpage_id`);

--
-- Indexes for table `module_subject_category`
--
ALTER TABLE `module_subject_category`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `webpage_id` (`webpage_id`);

--
-- Indexes for table `notify`
--
ALTER TABLE `notify`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `notify_group_id_fk` (`group_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `admin_id` (`admin_id`) USING BTREE,
  ADD KEY `user_id` (`user_id`) USING BTREE,
  ADD KEY `used_payment_id` (`used_payment_id`) USING BTREE,
  ADD KEY `event_member_id` (`event_member_id`),
  ADD KEY `contract_id` (`contract_id`),
  ADD KEY `payment_cms_group_id_fk` (`group_id`);

--
-- Indexes for table `payment_link`
--
ALTER TABLE `payment_link`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`hash_key`),
  ADD UNIQUE KEY `user_id_2` (`user_id`,`group_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `group_id` (`group_id`);

--
-- Indexes for table `ptg_callback_query`
--
ALTER TABLE `ptg_callback_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `chat_id_2` (`chat_id`,`message_id`);

--
-- Indexes for table `ptg_chat`
--
ALTER TABLE `ptg_chat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `old_id` (`old_id`);

--
-- Indexes for table `ptg_chat_join_request`
--
ALTER TABLE `ptg_chat_join_request`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `ptg_chat_member_updated`
--
ALTER TABLE `ptg_chat_member_updated`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `ptg_chosen_inline_result`
--
ALTER TABLE `ptg_chosen_inline_result`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `ptg_conversation`
--
ALTER TABLE `ptg_conversation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `ptg_edited_message`
--
ALTER TABLE `ptg_edited_message`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `chat_id_2` (`chat_id`,`message_id`);

--
-- Indexes for table `ptg_inline_query`
--
ALTER TABLE `ptg_inline_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `ptg_message`
--
ALTER TABLE `ptg_message`
  ADD PRIMARY KEY (`chat_id`,`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `forward_from` (`forward_from`),
  ADD KEY `forward_from_chat` (`forward_from_chat`),
  ADD KEY `reply_to_chat` (`reply_to_chat`),
  ADD KEY `reply_to_message` (`reply_to_message`),
  ADD KEY `via_bot` (`via_bot`),
  ADD KEY `left_chat_member` (`left_chat_member`),
  ADD KEY `migrate_from_chat_id` (`migrate_from_chat_id`),
  ADD KEY `migrate_to_chat_id` (`migrate_to_chat_id`),
  ADD KEY `reply_to_chat_2` (`reply_to_chat`,`reply_to_message`);

--
-- Indexes for table `ptg_poll`
--
ALTER TABLE `ptg_poll`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ptg_poll_answer`
--
ALTER TABLE `ptg_poll_answer`
  ADD PRIMARY KEY (`poll_id`,`user_id`);

--
-- Indexes for table `ptg_pre_checkout_query`
--
ALTER TABLE `ptg_pre_checkout_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `ptg_request_limiter`
--
ALTER TABLE `ptg_request_limiter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ptg_shipping_query`
--
ALTER TABLE `ptg_shipping_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `ptg_telegram_update`
--
ALTER TABLE `ptg_telegram_update`
  ADD PRIMARY KEY (`id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `chat_message_id` (`chat_id`,`message_id`),
  ADD KEY `edited_message_id` (`edited_message_id`),
  ADD KEY `channel_post_id` (`channel_post_id`),
  ADD KEY `edited_channel_post_id` (`edited_channel_post_id`),
  ADD KEY `inline_query_id` (`inline_query_id`),
  ADD KEY `chosen_inline_result_id` (`chosen_inline_result_id`),
  ADD KEY `callback_query_id` (`callback_query_id`),
  ADD KEY `shipping_query_id` (`shipping_query_id`),
  ADD KEY `pre_checkout_query_id` (`pre_checkout_query_id`),
  ADD KEY `poll_id` (`poll_id`),
  ADD KEY `poll_answer_poll_id` (`poll_answer_poll_id`),
  ADD KEY `my_chat_member_updated_id` (`my_chat_member_updated_id`),
  ADD KEY `chat_member_updated_id` (`chat_member_updated_id`),
  ADD KEY `chat_id` (`chat_id`,`channel_post_id`),
  ADD KEY `chat_join_request_id` (`chat_join_request_id`);

--
-- Indexes for table `ptg_user`
--
ALTER TABLE `ptg_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `ptg_user_chat`
--
ALTER TABLE `ptg_user_chat`
  ADD PRIMARY KEY (`user_id`,`chat_id`),
  ADD KEY `chat_id` (`chat_id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `parent_id` (`parent_id`) USING BTREE,
  ADD KEY `quiz_id` (`quiz_id`) USING BTREE;

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `subject_id` (`subject_id`) USING BTREE;

--
-- Indexes for table `quiz_result`
--
ALTER TABLE `quiz_result`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `hash` (`hash`) USING BTREE;

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `active` (`active`) USING BTREE,
  ADD KEY `webpage_id` (`webpage_id`);

--
-- Indexes for table `teacher_subject`
--
ALTER TABLE `teacher_subject`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `teacher_id` (`teacher_id`) USING BTREE,
  ADD KEY `subject_id` (`subject_id`) USING BTREE;

--
-- Indexes for table `tg_callback_query`
--
ALTER TABLE `tg_callback_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `chat_id_2` (`chat_id`,`message_id`);

--
-- Indexes for table `tg_chat`
--
ALTER TABLE `tg_chat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `old_id` (`old_id`);

--
-- Indexes for table `tg_chat_join_request`
--
ALTER TABLE `tg_chat_join_request`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tg_chat_member_updated`
--
ALTER TABLE `tg_chat_member_updated`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tg_chosen_inline_result`
--
ALTER TABLE `tg_chosen_inline_result`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tg_conversation`
--
ALTER TABLE `tg_conversation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `tg_edited_message`
--
ALTER TABLE `tg_edited_message`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `chat_id_2` (`chat_id`,`message_id`);

--
-- Indexes for table `tg_inline_query`
--
ALTER TABLE `tg_inline_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tg_message`
--
ALTER TABLE `tg_message`
  ADD PRIMARY KEY (`chat_id`,`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `forward_from` (`forward_from`),
  ADD KEY `forward_from_chat` (`forward_from_chat`),
  ADD KEY `reply_to_chat` (`reply_to_chat`),
  ADD KEY `reply_to_message` (`reply_to_message`),
  ADD KEY `via_bot` (`via_bot`),
  ADD KEY `left_chat_member` (`left_chat_member`),
  ADD KEY `migrate_from_chat_id` (`migrate_from_chat_id`),
  ADD KEY `migrate_to_chat_id` (`migrate_to_chat_id`),
  ADD KEY `reply_to_chat_2` (`reply_to_chat`,`reply_to_message`);

--
-- Indexes for table `tg_poll`
--
ALTER TABLE `tg_poll`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tg_poll_answer`
--
ALTER TABLE `tg_poll_answer`
  ADD PRIMARY KEY (`poll_id`,`user_id`);

--
-- Indexes for table `tg_pre_checkout_query`
--
ALTER TABLE `tg_pre_checkout_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tg_request_limiter`
--
ALTER TABLE `tg_request_limiter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tg_shipping_query`
--
ALTER TABLE `tg_shipping_query`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tg_telegram_update`
--
ALTER TABLE `tg_telegram_update`
  ADD PRIMARY KEY (`id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `chat_message_id` (`chat_id`,`message_id`),
  ADD KEY `edited_message_id` (`edited_message_id`),
  ADD KEY `channel_post_id` (`channel_post_id`),
  ADD KEY `edited_channel_post_id` (`edited_channel_post_id`),
  ADD KEY `inline_query_id` (`inline_query_id`),
  ADD KEY `chosen_inline_result_id` (`chosen_inline_result_id`),
  ADD KEY `callback_query_id` (`callback_query_id`),
  ADD KEY `shipping_query_id` (`shipping_query_id`),
  ADD KEY `pre_checkout_query_id` (`pre_checkout_query_id`),
  ADD KEY `poll_id` (`poll_id`),
  ADD KEY `poll_answer_poll_id` (`poll_answer_poll_id`),
  ADD KEY `my_chat_member_updated_id` (`my_chat_member_updated_id`),
  ADD KEY `chat_member_updated_id` (`chat_member_updated_id`),
  ADD KEY `chat_id` (`chat_id`,`channel_post_id`),
  ADD KEY `chat_join_request_id` (`chat_join_request_id`);

--
-- Indexes for table `tg_user`
--
ALTER TABLE `tg_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `tg_user_chat`
--
ALTER TABLE `tg_user_chat`
  ADD PRIMARY KEY (`user_id`,`chat_id`),
  ADD KEY `chat_id` (`chat_id`);

--
-- Indexes for table `tinified`
--
ALTER TABLE `tinified`
  ADD PRIMARY KEY (`fileName`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`) USING BTREE,
  ADD UNIQUE KEY `teacher_id` (`teacher_id`),
  ADD UNIQUE KEY `username` (`username`(191)) USING BTREE,
  ADD KEY `parent_id` (`parent_id`) USING BTREE,
  ADD KEY `money` (`money`) USING BTREE,
  ADD KEY `phone` (`phone`),
  ADD KEY `phone2` (`phone2`),
  ADD KEY `name` (`name`),
  ADD KEY `user_ibfk_3` (`created_by`);

--
-- Indexes for table `user_call`
--
ALTER TABLE `user_call`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`group_id`) USING BTREE;

--
-- Indexes for table `webpage`
--
ALTER TABLE `webpage`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `webpage_uk` (`url`) USING BTREE,
  ADD KEY `webpage_module` (`module_id`) USING BTREE;

--
-- Indexes for table `welcome_lesson`
--
ALTER TABLE `welcome_lesson`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `welcome_lesson_ibfk_5` (`created_by`);

--
-- Indexes for table `widget_html`
--
ALTER TABLE `widget_html`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `widget_menu`
--
ALTER TABLE `widget_menu`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `menu_language_id` (`language_id`) USING BTREE;

--
-- Indexes for table `widget_menu_item`
--
ALTER TABLE `widget_menu_item`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `menu_item_menu_id` (`menu_id`) USING BTREE,
  ADD KEY `menu_item_parent_id` (`parent_id`) USING BTREE,
  ADD KEY `menu_item_webpage_id` (`webpage_id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `action`
--
ALTER TABLE `action`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `age_confirmation`
--
ALTER TABLE `age_confirmation`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth`
--
ALTER TABLE `auth`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `bot_mailing`
--
ALTER TABLE `bot_mailing`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bot_push`
--
ALTER TABLE `bot_push`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID компании';

--
-- AUTO_INCREMENT for table `confirmation_code`
--
ALTER TABLE `confirmation_code`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `consultation`
--
ALTER TABLE `consultation`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contract`
--
ALTER TABLE `contract`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `email_queue`
--
ALTER TABLE `email_queue`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `errors`
--
ALTER TABLE `errors`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `event_member`
--
ALTER TABLE `event_member`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `gift_card`
--
ALTER TABLE `gift_card`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `gift_card_type`
--
ALTER TABLE `gift_card_type`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `group`
--
ALTER TABLE `group`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID группы';

--
-- AUTO_INCREMENT for table `group_note`
--
ALTER TABLE `group_note`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `group_param`
--
ALTER TABLE `group_param`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `group_pupil`
--
ALTER TABLE `group_pupil`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `group_type`
--
ALTER TABLE `group_type`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `high_school`
--
ALTER TABLE `high_school`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID ВУЗа';

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `language_id` tinyint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `id` tinyint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `module_blog`
--
ALTER TABLE `module_blog`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID статьи';

--
-- AUTO_INCREMENT for table `module_feedback`
--
ALTER TABLE `module_feedback`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID сообщения';

--
-- AUTO_INCREMENT for table `module_news`
--
ALTER TABLE `module_news`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID новости';

--
-- AUTO_INCREMENT for table `module_order`
--
ALTER TABLE `module_order`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `module_page`
--
ALTER TABLE `module_page`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `module_promotions`
--
ALTER TABLE `module_promotions`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID акции';

--
-- AUTO_INCREMENT for table `module_review`
--
ALTER TABLE `module_review`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID отзыва';

--
-- AUTO_INCREMENT for table `module_subject`
--
ALTER TABLE `module_subject`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID предмета';

--
-- AUTO_INCREMENT for table `module_subject_category`
--
ALTER TABLE `module_subject_category`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id';

--
-- AUTO_INCREMENT for table `notify`
--
ALTER TABLE `notify`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `payment_link`
--
ALTER TABLE `payment_link`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `ptg_chat_join_request`
--
ALTER TABLE `ptg_chat_join_request`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `ptg_chat_member_updated`
--
ALTER TABLE `ptg_chat_member_updated`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `ptg_chosen_inline_result`
--
ALTER TABLE `ptg_chosen_inline_result`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `ptg_conversation`
--
ALTER TABLE `ptg_conversation`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `ptg_edited_message`
--
ALTER TABLE `ptg_edited_message`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `ptg_request_limiter`
--
ALTER TABLE `ptg_request_limiter`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID теста';

--
-- AUTO_INCREMENT for table `quiz_result`
--
ALTER TABLE `quiz_result`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID учителя';

--
-- AUTO_INCREMENT for table `teacher_subject`
--
ALTER TABLE `teacher_subject`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `tg_chat_join_request`
--
ALTER TABLE `tg_chat_join_request`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `tg_chat_member_updated`
--
ALTER TABLE `tg_chat_member_updated`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `tg_chosen_inline_result`
--
ALTER TABLE `tg_chosen_inline_result`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `tg_conversation`
--
ALTER TABLE `tg_conversation`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `tg_edited_message`
--
ALTER TABLE `tg_edited_message`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `tg_request_limiter`
--
ALTER TABLE `tg_request_limiter`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry';

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_call`
--
ALTER TABLE `user_call`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `group_id` tinyint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `webpage`
--
ALTER TABLE `webpage`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `welcome_lesson`
--
ALTER TABLE `welcome_lesson`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT for table `widget_html`
--
ALTER TABLE `widget_html`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `widget_menu`
--
ALTER TABLE `widget_menu`
  MODIFY `id` tinyint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT for table `widget_menu_item`
--
ALTER TABLE `widget_menu_item`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- Constraints for dumped tables
--

--
-- Constraints for table `action`
--
ALTER TABLE `action`
  ADD CONSTRAINT `action_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `action_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `action_ibfk_3` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`);

--
-- Constraints for table `age_confirmation`
--
ALTER TABLE `age_confirmation`
  ADD CONSTRAINT `age_confirmation_FK` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bot_mailing`
--
ALTER TABLE `bot_mailing`
  ADD CONSTRAINT `FK__user` FOREIGN KEY (`admin_id`) REFERENCES `user` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `consultation`
--
ALTER TABLE `consultation`
  ADD CONSTRAINT `FK_consultation_module_subject` FOREIGN KEY (`subject_id`) REFERENCES `module_subject` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_consultation_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_consultation_user_2` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `contract`
--
ALTER TABLE `contract`
  ADD CONSTRAINT `contract_created_user_id_fk` FOREIGN KEY (`created_admin_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `contract_group_id_fk` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `contract_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `contract_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  ADD CONSTRAINT `contract_paid_user_id_fk` FOREIGN KEY (`paid_admin_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `debt`
--
ALTER TABLE `debt`
  ADD CONSTRAINT `debt_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `debt_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `event`
--
ALTER TABLE `event`
  ADD CONSTRAINT `event_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `event_member`
--
ALTER TABLE `event_member`
  ADD CONSTRAINT `event_member_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `event_member_ibfk_2` FOREIGN KEY (`group_pupil_id`) REFERENCES `group_pupil` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `group`
--
ALTER TABLE `group`
  ADD CONSTRAINT `group_group_type_id_fk` FOREIGN KEY (`type_id`) REFERENCES `group_type` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `group_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `module_subject` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `group_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `group_note`
--
ALTER TABLE `group_note`
  ADD CONSTRAINT `group_note_FK` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `group_note_FK_1` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`id`);

--
-- Constraints for table `group_param`
--
ALTER TABLE `group_param`
  ADD CONSTRAINT `group_param_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `group_param_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `group_pupil`
--
ALTER TABLE `group_pupil`
  ADD CONSTRAINT `group_pupil_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `group_pupil_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `module_blog`
--
ALTER TABLE `module_blog`
  ADD CONSTRAINT `module_blog_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `module_news`
--
ALTER TABLE `module_news`
  ADD CONSTRAINT `module_news_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `module_page`
--
ALTER TABLE `module_page`
  ADD CONSTRAINT `module_page_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `module_promotions`
--
ALTER TABLE `module_promotions`
  ADD CONSTRAINT `module_promotions_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `module_subject`
--
ALTER TABLE `module_subject`
  ADD CONSTRAINT `module_subject_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `module_subject_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `module_subject_ibfk_2` FOREIGN KEY (`webpage_id`) REFERENCES `webpage` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `module_subject_category`
--
ALTER TABLE `module_subject_category`
  ADD CONSTRAINT `module_subject_category_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `webpage` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `notify`
--
ALTER TABLE `notify`
  ADD CONSTRAINT `notify_group_id_fk` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `notify_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_cms_group_id_fk` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_ibfk_4` FOREIGN KEY (`used_payment_id`) REFERENCES `payment` (`id`),
  ADD CONSTRAINT `payment_ibfk_7` FOREIGN KEY (`event_member_id`) REFERENCES `event_member` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_ibfk_8` FOREIGN KEY (`contract_id`) REFERENCES `contract` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `payment_link`
--
ALTER TABLE `payment_link`
  ADD CONSTRAINT `payment_link_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_link_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ptg_callback_query`
--
ALTER TABLE `ptg_callback_query`
  ADD CONSTRAINT `ptg_callback_query_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`),
  ADD CONSTRAINT `ptg_callback_query_ibfk_2` FOREIGN KEY (`chat_id`,`message_id`) REFERENCES `ptg_message` (`chat_id`, `id`);

--
-- Constraints for table `ptg_chat_join_request`
--
ALTER TABLE `ptg_chat_join_request`
  ADD CONSTRAINT `ptg_chat_join_request_ibfk_1` FOREIGN KEY (`chat_id`) REFERENCES `ptg_chat` (`id`),
  ADD CONSTRAINT `ptg_chat_join_request_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_chat_member_updated`
--
ALTER TABLE `ptg_chat_member_updated`
  ADD CONSTRAINT `ptg_chat_member_updated_ibfk_1` FOREIGN KEY (`chat_id`) REFERENCES `ptg_chat` (`id`),
  ADD CONSTRAINT `ptg_chat_member_updated_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_chosen_inline_result`
--
ALTER TABLE `ptg_chosen_inline_result`
  ADD CONSTRAINT `ptg_chosen_inline_result_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_conversation`
--
ALTER TABLE `ptg_conversation`
  ADD CONSTRAINT `ptg_conversation_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`),
  ADD CONSTRAINT `ptg_conversation_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `ptg_chat` (`id`);

--
-- Constraints for table `ptg_edited_message`
--
ALTER TABLE `ptg_edited_message`
  ADD CONSTRAINT `ptg_edited_message_ibfk_1` FOREIGN KEY (`chat_id`) REFERENCES `ptg_chat` (`id`),
  ADD CONSTRAINT `ptg_edited_message_ibfk_2` FOREIGN KEY (`chat_id`,`message_id`) REFERENCES `ptg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `ptg_edited_message_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_inline_query`
--
ALTER TABLE `ptg_inline_query`
  ADD CONSTRAINT `ptg_inline_query_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_message`
--
ALTER TABLE `ptg_message`
  ADD CONSTRAINT `ptg_message_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`),
  ADD CONSTRAINT `ptg_message_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `ptg_chat` (`id`),
  ADD CONSTRAINT `ptg_message_ibfk_3` FOREIGN KEY (`forward_from`) REFERENCES `ptg_user` (`id`),
  ADD CONSTRAINT `ptg_message_ibfk_4` FOREIGN KEY (`forward_from_chat`) REFERENCES `ptg_chat` (`id`),
  ADD CONSTRAINT `ptg_message_ibfk_5` FOREIGN KEY (`reply_to_chat`,`reply_to_message`) REFERENCES `ptg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `ptg_message_ibfk_6` FOREIGN KEY (`via_bot`) REFERENCES `ptg_user` (`id`),
  ADD CONSTRAINT `ptg_message_ibfk_7` FOREIGN KEY (`left_chat_member`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_poll_answer`
--
ALTER TABLE `ptg_poll_answer`
  ADD CONSTRAINT `ptg_poll_answer_ibfk_1` FOREIGN KEY (`poll_id`) REFERENCES `ptg_poll` (`id`);

--
-- Constraints for table `ptg_pre_checkout_query`
--
ALTER TABLE `ptg_pre_checkout_query`
  ADD CONSTRAINT `ptg_pre_checkout_query_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_shipping_query`
--
ALTER TABLE `ptg_shipping_query`
  ADD CONSTRAINT `ptg_shipping_query_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`);

--
-- Constraints for table `ptg_telegram_update`
--
ALTER TABLE `ptg_telegram_update`
  ADD CONSTRAINT `ptg_telegram_update_ibfk_1` FOREIGN KEY (`chat_id`,`message_id`) REFERENCES `ptg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_10` FOREIGN KEY (`poll_id`) REFERENCES `ptg_poll` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_11` FOREIGN KEY (`poll_answer_poll_id`) REFERENCES `ptg_poll_answer` (`poll_id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_12` FOREIGN KEY (`my_chat_member_updated_id`) REFERENCES `ptg_chat_member_updated` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_13` FOREIGN KEY (`chat_member_updated_id`) REFERENCES `ptg_chat_member_updated` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_14` FOREIGN KEY (`chat_join_request_id`) REFERENCES `ptg_chat_join_request` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_2` FOREIGN KEY (`edited_message_id`) REFERENCES `ptg_edited_message` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_3` FOREIGN KEY (`chat_id`,`channel_post_id`) REFERENCES `ptg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_4` FOREIGN KEY (`edited_channel_post_id`) REFERENCES `ptg_edited_message` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_5` FOREIGN KEY (`inline_query_id`) REFERENCES `ptg_inline_query` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_6` FOREIGN KEY (`chosen_inline_result_id`) REFERENCES `ptg_chosen_inline_result` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_7` FOREIGN KEY (`callback_query_id`) REFERENCES `ptg_callback_query` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_8` FOREIGN KEY (`shipping_query_id`) REFERENCES `ptg_shipping_query` (`id`),
  ADD CONSTRAINT `ptg_telegram_update_ibfk_9` FOREIGN KEY (`pre_checkout_query_id`) REFERENCES `ptg_pre_checkout_query` (`id`);

--
-- Constraints for table `ptg_user_chat`
--
ALTER TABLE `ptg_user_chat`
  ADD CONSTRAINT `ptg_user_chat_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ptg_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ptg_user_chat_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `ptg_chat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tg_callback_query`
--
ALTER TABLE `tg_callback_query`
  ADD CONSTRAINT `tg_callback_query_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`),
  ADD CONSTRAINT `tg_callback_query_ibfk_2` FOREIGN KEY (`chat_id`,`message_id`) REFERENCES `tg_message` (`chat_id`, `id`);

--
-- Constraints for table `tg_chat_join_request`
--
ALTER TABLE `tg_chat_join_request`
  ADD CONSTRAINT `tg_chat_join_request_ibfk_1` FOREIGN KEY (`chat_id`) REFERENCES `tg_chat` (`id`),
  ADD CONSTRAINT `tg_chat_join_request_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_chat_member_updated`
--
ALTER TABLE `tg_chat_member_updated`
  ADD CONSTRAINT `tg_chat_member_updated_ibfk_1` FOREIGN KEY (`chat_id`) REFERENCES `tg_chat` (`id`),
  ADD CONSTRAINT `tg_chat_member_updated_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_chosen_inline_result`
--
ALTER TABLE `tg_chosen_inline_result`
  ADD CONSTRAINT `tg_chosen_inline_result_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_conversation`
--
ALTER TABLE `tg_conversation`
  ADD CONSTRAINT `tg_conversation_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`),
  ADD CONSTRAINT `tg_conversation_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `tg_chat` (`id`);

--
-- Constraints for table `tg_edited_message`
--
ALTER TABLE `tg_edited_message`
  ADD CONSTRAINT `tg_edited_message_ibfk_1` FOREIGN KEY (`chat_id`) REFERENCES `tg_chat` (`id`),
  ADD CONSTRAINT `tg_edited_message_ibfk_2` FOREIGN KEY (`chat_id`,`message_id`) REFERENCES `tg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `tg_edited_message_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_inline_query`
--
ALTER TABLE `tg_inline_query`
  ADD CONSTRAINT `tg_inline_query_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_message`
--
ALTER TABLE `tg_message`
  ADD CONSTRAINT `tg_message_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`),
  ADD CONSTRAINT `tg_message_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `tg_chat` (`id`),
  ADD CONSTRAINT `tg_message_ibfk_3` FOREIGN KEY (`forward_from`) REFERENCES `tg_user` (`id`),
  ADD CONSTRAINT `tg_message_ibfk_4` FOREIGN KEY (`forward_from_chat`) REFERENCES `tg_chat` (`id`),
  ADD CONSTRAINT `tg_message_ibfk_5` FOREIGN KEY (`reply_to_chat`,`reply_to_message`) REFERENCES `tg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `tg_message_ibfk_6` FOREIGN KEY (`via_bot`) REFERENCES `tg_user` (`id`),
  ADD CONSTRAINT `tg_message_ibfk_7` FOREIGN KEY (`left_chat_member`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_poll_answer`
--
ALTER TABLE `tg_poll_answer`
  ADD CONSTRAINT `tg_poll_answer_ibfk_1` FOREIGN KEY (`poll_id`) REFERENCES `tg_poll` (`id`);

--
-- Constraints for table `tg_pre_checkout_query`
--
ALTER TABLE `tg_pre_checkout_query`
  ADD CONSTRAINT `tg_pre_checkout_query_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_shipping_query`
--
ALTER TABLE `tg_shipping_query`
  ADD CONSTRAINT `tg_shipping_query_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`);

--
-- Constraints for table `tg_telegram_update`
--
ALTER TABLE `tg_telegram_update`
  ADD CONSTRAINT `tg_telegram_update_ibfk_1` FOREIGN KEY (`chat_id`,`message_id`) REFERENCES `tg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_10` FOREIGN KEY (`poll_id`) REFERENCES `tg_poll` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_11` FOREIGN KEY (`poll_answer_poll_id`) REFERENCES `tg_poll_answer` (`poll_id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_12` FOREIGN KEY (`my_chat_member_updated_id`) REFERENCES `tg_chat_member_updated` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_13` FOREIGN KEY (`chat_member_updated_id`) REFERENCES `tg_chat_member_updated` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_14` FOREIGN KEY (`chat_join_request_id`) REFERENCES `tg_chat_join_request` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_2` FOREIGN KEY (`edited_message_id`) REFERENCES `tg_edited_message` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_3` FOREIGN KEY (`chat_id`,`channel_post_id`) REFERENCES `tg_message` (`chat_id`, `id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_4` FOREIGN KEY (`edited_channel_post_id`) REFERENCES `tg_edited_message` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_5` FOREIGN KEY (`inline_query_id`) REFERENCES `tg_inline_query` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_6` FOREIGN KEY (`chosen_inline_result_id`) REFERENCES `tg_chosen_inline_result` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_7` FOREIGN KEY (`callback_query_id`) REFERENCES `tg_callback_query` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_8` FOREIGN KEY (`shipping_query_id`) REFERENCES `tg_shipping_query` (`id`),
  ADD CONSTRAINT `tg_telegram_update_ibfk_9` FOREIGN KEY (`pre_checkout_query_id`) REFERENCES `tg_pre_checkout_query` (`id`);

--
-- Constraints for table `tg_user_chat`
--
ALTER TABLE `tg_user_chat`
  ADD CONSTRAINT `tg_user_chat_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tg_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tg_user_chat_ibfk_2` FOREIGN KEY (`chat_id`) REFERENCES `tg_chat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `user_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `welcome_lesson`
--
ALTER TABLE `welcome_lesson`
  ADD CONSTRAINT `welcome_lesson_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `module_subject` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `welcome_lesson_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `welcome_lesson_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `welcome_lesson_ibfk_4` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `welcome_lesson_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
