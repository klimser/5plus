-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Окт 19 2018 г., 17:58
-- Версия сервера: 5.7.17
-- Версия PHP: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `5plus`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cms_action`
--

CREATE TABLE `cms_action` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `type` int(10) UNSIGNED NOT NULL COMMENT 'Тип записи',
  `admin_id` int(10) UNSIGNED NOT NULL COMMENT 'ID админа',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID клиента',
  `group_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID группы',
  `amount` int(11) NOT NULL COMMENT 'Сумма операции',
  `comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Комментарий к операции',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Дата операции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_auth`
--

CREATE TABLE `cms_auth` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID пользователя',
  `source` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Источник',
  `source_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Идентификатор в системе источника'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_contract`
--

CREATE TABLE `cms_contract` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `number` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Номер договора',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID ученика',
  `group_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Группа',
  `amount` int(10) UNSIGNED NOT NULL COMMENT 'Сумма',
  `discount` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Со скидкой',
  `status` tinyint(4) DEFAULT '0' COMMENT 'Статус оплаты',
  `payment_type` tinyint(4) DEFAULT NULL COMMENT 'Тип оплаты',
  `external_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ID транзакции в платёжной системе',
  `created_at` datetime DEFAULT NULL COMMENT 'Дата создания',
  `created_admin_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Кто добавил',
  `paid_at` datetime DEFAULT NULL COMMENT 'Дата оплаты',
  `paid_admin_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Кто отметил оплаченным'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_debt`
--

CREATE TABLE `cms_debt` (
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID должника',
  `amount` float NOT NULL COMMENT 'Сумма задолженности',
  `comment` text COLLATE utf8_unicode_ci COMMENT 'Комментарий (за что должен)',
  `danger_date` timestamp NULL DEFAULT NULL COMMENT 'Дата недопуска'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_email_queue`
--

CREATE TABLE `cms_email_queue` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `template_html` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'HTML-шаблон',
  `template_text` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Текстовый шаблон',
  `params` text COLLATE utf8_unicode_ci COMMENT 'Параметры для передачи в шаблон',
  `sender` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Отправитель',
  `recipient` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Получатель',
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Тема',
  `state` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Статус отправки',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Дата добавления',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Дата обновления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_errors`
--

CREATE TABLE `cms_errors` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `module` varchar(255) NOT NULL COMMENT 'Место ошибки',
  `content` text NOT NULL COMMENT 'Содержимое ошибки',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_event`
--

CREATE TABLE `cms_event` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `group_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID группы',
  `event_date` datetime NOT NULL COMMENT 'Дата занятия',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Статус занятия'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_event_member`
--

CREATE TABLE `cms_event_member` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `group_pupil_id` int(10) UNSIGNED NOT NULL COMMENT 'ID ученика в группе',
  `event_id` int(10) UNSIGNED NOT NULL COMMENT 'ID занятия',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Статус присутствия',
  `mark` tinyint(4) DEFAULT NULL COMMENT 'Оценка'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_group`
--

CREATE TABLE `cms_group` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID группы',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название группы',
  `legal_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Официальное название (для договора)',
  `type_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Тип группы',
  `subject_id` int(10) UNSIGNED NOT NULL COMMENT 'ID предмета',
  `teacher_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID учителя',
  `schedule` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'График занятий группы',
  `weekday` char(6) COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000' COMMENT 'В какие дни недели занятия',
  `lesson_price` int(10) UNSIGNED NOT NULL COMMENT 'Цена занятия',
  `lesson_price_discount` int(10) UNSIGNED DEFAULT NULL COMMENT 'Цена занятия со скидкой',
  `teacher_rate` float DEFAULT '0' COMMENT 'Процент начислений зарплаты учителю',
  `room_number` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Номер кабинета',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Занимается ли группа',
  `date_start` date DEFAULT NULL COMMENT 'Дата начала занятий',
  `date_end` date DEFAULT NULL COMMENT 'Дата завершения занятий',
  `date_charge_till` timestamp NULL DEFAULT NULL COMMENT 'Стоимость списана до этой даты'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_group_param`
--

CREATE TABLE `cms_group_param` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `group_id` int(10) UNSIGNED NOT NULL COMMENT 'Группа',
  `year` smallint(5) UNSIGNED NOT NULL COMMENT 'год',
  `month` tinyint(3) UNSIGNED NOT NULL COMMENT 'месяц',
  `lesson_price` int(10) UNSIGNED NOT NULL COMMENT 'Цена занятия',
  `lesson_price_discount` int(10) UNSIGNED DEFAULT NULL COMMENT 'Цена занятия со скидкой',
  `schedule` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'График занятий группы ',
  `weekday` char(6) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Расписание',
  `teacher_id` int(10) UNSIGNED NOT NULL COMMENT 'Учитель',
  `teacher_rate` float NOT NULL COMMENT 'Процент учителю',
  `teacher_salary` int(10) UNSIGNED DEFAULT NULL COMMENT 'Зарплата учителя'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_group_pupil`
--

CREATE TABLE `cms_group_pupil` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID ученика',
  `group_id` int(10) UNSIGNED NOT NULL COMMENT 'ID группы',
  `active` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Активен ли студент',
  `date_start` date DEFAULT NULL COMMENT 'Дата начала занятий',
  `date_end` date DEFAULT NULL COMMENT 'Дата завершения занятий',
  `date_charge_till` timestamp NULL DEFAULT NULL COMMENT 'Стоимость списана до этой даты',
  `paid_lessons` int(11) NOT NULL DEFAULT '0' COMMENT 'Сколько оплаченных занятий осталось'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_group_type`
--

CREATE TABLE `cms_group_type` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_high_school`
--

CREATE TABLE `cms_high_school` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID ВУЗа',
  `type` tinyint(4) NOT NULL COMMENT 'Тип учебного заведения',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название учебного заведения',
  `name_short` varchar(127) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Аббревиатура',
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Фото',
  `short_description` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Краткое описание',
  `description` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Полное описание',
  `page_order` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Порядок отображения на странице',
  `active` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Показывать'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module`
--

CREATE TABLE `cms_module` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `controller` char(50) DEFAULT NULL,
  `action` char(50) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `url_prefix` varchar(50) DEFAULT NULL COMMENT 'Префикс URL',
  `field_for_url` varchar(50) DEFAULT NULL COMMENT 'Поле, которое использовать для генерации URL',
  `field_for_title` varchar(50) DEFAULT NULL COMMENT 'Поле, из которого скопировать Title',
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_feedback`
--

CREATE TABLE `cms_module_feedback` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID сообщения',
  `name` varchar(50) NOT NULL COMMENT 'Имя пользователя',
  `contact` varchar(255) NOT NULL COMMENT 'Как с ним связаться',
  `message` text NOT NULL COMMENT 'Сообщение',
  `ip` varchar(40) NOT NULL COMMENT 'IP адрес отправителя',
  `status` enum('new','read','completed') NOT NULL DEFAULT 'new' COMMENT 'Статус',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_order`
--

CREATE TABLE `cms_module_order` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `subject` varchar(127) NOT NULL COMMENT 'Предмет',
  `name` varchar(50) NOT NULL COMMENT 'Имя',
  `phone` char(13) NOT NULL COMMENT 'Телефон',
  `email` varchar(50) DEFAULT NULL COMMENT 'E-mail',
  `status` enum('unread','read','done','problem') NOT NULL DEFAULT 'unread' COMMENT 'Статус заявки',
  `user_comment` varchar(255) DEFAULT NULL COMMENT 'Комментарии от заказчика',
  `admin_comment` varchar(255) DEFAULT NULL COMMENT 'Комментарии админа',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата подачи'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_order_subject`
--

CREATE TABLE `cms_module_order_subject` (
  `name` varchar(127) NOT NULL COMMENT 'Название предмета'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_page`
--

CREATE TABLE `cms_module_page` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `title` varchar(255) NOT NULL COMMENT 'Заголовок',
  `content` text NOT NULL COMMENT 'Содержимое',
  `webpage_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'ID webpage',
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'активна',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_review`
--

CREATE TABLE `cms_module_review` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID отзыва',
  `name` varchar(50) NOT NULL COMMENT 'Имя автора',
  `age` tinyint(4) DEFAULT NULL COMMENT 'Возраст автора',
  `message` varchar(1000) NOT NULL COMMENT 'Текст отзыва',
  `status` enum('new','approved') NOT NULL DEFAULT 'new' COMMENT 'Статус отзыва',
  `ip` varchar(40) NOT NULL COMMENT 'IP адрес отправителя',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_subject`
--

CREATE TABLE `cms_module_subject` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID предмета',
  `name` varchar(50) NOT NULL COMMENT 'Название предмета',
  `category_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID группы',
  `image` varchar(255) DEFAULT NULL COMMENT 'Картинка',
  `description` text NOT NULL COMMENT 'Тизер',
  `content` text NOT NULL COMMENT 'Контент',
  `webpage_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Активен'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_subject_category`
--

CREATE TABLE `cms_module_subject_category` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'id',
  `name` varchar(255) NOT NULL COMMENT 'Название группы',
  `webpage_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID страницы'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_payment`
--

CREATE TABLE `cms_payment` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `user_id` int(10) UNSIGNED NOT NULL COMMENT 'ID студента',
  `admin_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID админа',
  `group_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Группа',
  `group_pupil_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID ученика в группе',
  `amount` int(11) NOT NULL COMMENT 'Сумма',
  `discount` tinyint(4) DEFAULT '0' COMMENT 'Скидочный платёж',
  `comment` text COLLATE utf8_unicode_ci COMMENT 'Комментарий',
  `contract` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Номер договора',
  `contract_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID договора',
  `used_payment_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID использованного при списании платежа',
  `event_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Событие',
  `event_member_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID занятия',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата операции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_question`
--

CREATE TABLE `cms_question` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `quiz_id` int(10) UNSIGNED NOT NULL COMMENT 'ID теста',
  `parent_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Вопрос',
  `content` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Текст вопроса/ответа',
  `is_right` tinyint(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Правильный ответ',
  `sort_order` int(10) UNSIGNED DEFAULT NULL COMMENT 'Порядок вопроса'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_quiz`
--

CREATE TABLE `cms_quiz` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID теста',
  `subject_id` int(10) UNSIGNED NOT NULL COMMENT 'ID предмета',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название',
  `page_order` int(10) UNSIGNED DEFAULT NULL COMMENT 'Порядок отображения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_quiz_result`
--

CREATE TABLE `cms_quiz_result` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ключ записи',
  `student_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Имя студента',
  `subject_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название предмета',
  `quiz_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Название теста',
  `questions_data` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT 'Вопросы',
  `answers_data` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Ответы',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Время начала теста',
  `finished_at` timestamp NULL DEFAULT NULL COMMENT 'Время завершения теста'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_teacher`
--

CREATE TABLE `cms_teacher` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID учителя',
  `name` varchar(127) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ФИО',
  `phone` char(13) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Телефон',
  `birthday` date DEFAULT NULL COMMENT 'День рождения',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Как представлять учителя',
  `description` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Описание',
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Фото',
  `webpage_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `page_visibility` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Отображать на странице учителей',
  `page_order` int(11) NOT NULL DEFAULT '0' COMMENT 'Порядок отображения на странице учителей',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Работает ли учитель'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_teacher_subject`
--

CREATE TABLE `cms_teacher_subject` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `teacher_id` int(10) UNSIGNED NOT NULL COMMENT 'ID учителя',
  `subject_id` int(10) UNSIGNED NOT NULL COMMENT 'ID предмета'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_user`
--

CREATE TABLE `cms_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(127) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Имя пользователя',
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` char(13) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Телефон',
  `phone2` char(13) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Доп. телефон',
  `status` smallint(6) NOT NULL DEFAULT '10',
  `money` int(11) NOT NULL DEFAULT '0' COMMENT 'Баланс',
  `role` tinyint(4) NOT NULL COMMENT 'Уровень доступа пользователя',
  `parent_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Родитель',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Дата добавления',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Дата изменения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_webpage`
--

CREATE TABLE `cms_webpage` (
  `id` int(11) UNSIGNED NOT NULL,
  `url` char(255) NOT NULL DEFAULT '',
  `main` tinyint(1) UNSIGNED DEFAULT NULL,
  `title` char(255) DEFAULT NULL,
  `description` text,
  `keywords` text,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `module_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `record_id` int(11) UNSIGNED DEFAULT NULL,
  `inrobots` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_widget_html`
--

CREATE TABLE `cms_widget_html` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `editor` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Визуальный редактор'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_widget_menu`
--

CREATE TABLE `cms_widget_menu` (
  `id` tinyint(3) UNSIGNED NOT NULL COMMENT 'ID',
  `name` varchar(63) NOT NULL COMMENT 'Название меню',
  `title` varchar(255) DEFAULT NULL COMMENT 'Заголовок меню',
  `language_id` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Язык'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_widget_menu_item`
--

CREATE TABLE `cms_widget_menu_item` (
  `id` int(11) UNSIGNED NOT NULL COMMENT 'ID',
  `menu_id` tinyint(3) UNSIGNED NOT NULL COMMENT 'Меню',
  `parent_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Родительский пункт меню',
  `webpage_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Ссылка на страницу сайта',
  `url` varchar(255) DEFAULT NULL COMMENT 'URL',
  `title` varchar(127) DEFAULT NULL COMMENT 'Текст пункта меню',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Показывать или нет',
  `attr` text COMMENT 'Доп параметры',
  `orderby` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Порядок'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cms_action`
--
ALTER TABLE `cms_action`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `group_id` (`group_id`);

--
-- Индексы таблицы `cms_auth`
--
ALTER TABLE `cms_auth`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cms_auth_cms_user_id_fk` (`user_id`);

--
-- Индексы таблицы `cms_contract`
--
ALTER TABLE `cms_contract`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cms_contract_number_uindex` (`number`),
  ADD KEY `cms_contract_cms_user_id_fk` (`user_id`),
  ADD KEY `cms_contract_group_id_index` (`group_id`),
  ADD KEY `contract_created_user_id_fk` (`created_admin_id`),
  ADD KEY `contract_paid_user_id_fk` (`paid_admin_id`);

--
-- Индексы таблицы `cms_debt`
--
ALTER TABLE `cms_debt`
  ADD PRIMARY KEY (`user_id`);

--
-- Индексы таблицы `cms_email_queue`
--
ALTER TABLE `cms_email_queue`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cms_errors`
--
ALTER TABLE `cms_errors`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cms_event`
--
ALTER TABLE `cms_event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_id` (`group_id`);

--
-- Индексы таблицы `cms_event_member`
--
ALTER TABLE `cms_event_member`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event_id` (`event_id`),
  ADD KEY `group_pupil_id` (`group_pupil_id`);

--
-- Индексы таблицы `cms_group`
--
ALTER TABLE `cms_group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `cms_group_cms_group_type_id_fk` (`type_id`);

--
-- Индексы таблицы `cms_group_param`
--
ALTER TABLE `cms_group_param`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `group_id` (`group_id`,`year`,`month`) USING BTREE,
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Индексы таблицы `cms_group_pupil`
--
ALTER TABLE `cms_group_pupil`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `group_id` (`group_id`);

--
-- Индексы таблицы `cms_group_type`
--
ALTER TABLE `cms_group_type`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cms_high_school`
--
ALTER TABLE `cms_high_school`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cms_module`
--
ALTER TABLE `cms_module`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `module_ukey` (`controller`,`action`);

--
-- Индексы таблицы `cms_module_feedback`
--
ALTER TABLE `cms_module_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cms_module_order`
--
ALTER TABLE `cms_module_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject` (`subject`);

--
-- Индексы таблицы `cms_module_order_subject`
--
ALTER TABLE `cms_module_order_subject`
  ADD PRIMARY KEY (`name`);

--
-- Индексы таблицы `cms_module_page`
--
ALTER TABLE `cms_module_page`
  ADD PRIMARY KEY (`id`),
  ADD KEY `page_webpage_id` (`webpage_id`);

--
-- Индексы таблицы `cms_module_review`
--
ALTER TABLE `cms_module_review`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cms_module_subject`
--
ALTER TABLE `cms_module_subject`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`,`category_id`) USING BTREE,
  ADD KEY `category_id` (`category_id`),
  ADD KEY `webpage_id` (`webpage_id`);

--
-- Индексы таблицы `cms_module_subject_category`
--
ALTER TABLE `cms_module_subject_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `webpage_id` (`webpage_id`);

--
-- Индексы таблицы `cms_payment`
--
ALTER TABLE `cms_payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `used_payment_id` (`used_payment_id`),
  ADD KEY `group_pupil_id` (`group_pupil_id`),
  ADD KEY `event_id` (`event_id`),
  ADD KEY `event_member_id` (`event_member_id`),
  ADD KEY `cms_payment_cms_contract_id_fk` (`contract_id`),
  ADD KEY `cms_payment_cms_group_id_fk` (`group_id`);

--
-- Индексы таблицы `cms_question`
--
ALTER TABLE `cms_question`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `quiz_id` (`quiz_id`) USING BTREE;

--
-- Индексы таблицы `cms_quiz`
--
ALTER TABLE `cms_quiz`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Индексы таблицы `cms_quiz_result`
--
ALTER TABLE `cms_quiz_result`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cms_teacher`
--
ALTER TABLE `cms_teacher`
  ADD PRIMARY KEY (`id`),
  ADD KEY `active` (`active`),
  ADD KEY `webpage_id` (`webpage_id`);

--
-- Индексы таблицы `cms_teacher_subject`
--
ALTER TABLE `cms_teacher_subject`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Индексы таблицы `cms_user`
--
ALTER TABLE `cms_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `money` (`money`),
  ADD KEY `phone` (`phone`),
  ADD KEY `phone2` (`phone2`),
  ADD KEY `username` (`username`) USING BTREE;

--
-- Индексы таблицы `cms_webpage`
--
ALTER TABLE `cms_webpage`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `webpage_uk` (`url`),
  ADD KEY `webpage_module` (`module_id`) USING BTREE;

--
-- Индексы таблицы `cms_widget_html`
--
ALTER TABLE `cms_widget_html`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `cms_widget_menu`
--
ALTER TABLE `cms_widget_menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_language_id` (`language_id`);

--
-- Индексы таблицы `cms_widget_menu_item`
--
ALTER TABLE `cms_widget_menu_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_item_menu_id` (`menu_id`),
  ADD KEY `menu_item_parent_id` (`parent_id`),
  ADD KEY `menu_item_webpage_id` (`webpage_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cms_action`
--
ALTER TABLE `cms_action`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT для таблицы `cms_auth`
--
ALTER TABLE `cms_auth`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT для таблицы `cms_contract`
--
ALTER TABLE `cms_contract`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT для таблицы `cms_email_queue`
--
ALTER TABLE `cms_email_queue`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT для таблицы `cms_errors`
--
ALTER TABLE `cms_errors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT для таблицы `cms_event`
--
ALTER TABLE `cms_event`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT для таблицы `cms_event_member`
--
ALTER TABLE `cms_event_member`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT для таблицы `cms_group`
--
ALTER TABLE `cms_group`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID группы';

--
-- AUTO_INCREMENT для таблицы `cms_group_param`
--
ALTER TABLE `cms_group_param`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT для таблицы `cms_group_pupil`
--
ALTER TABLE `cms_group_pupil`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT для таблицы `cms_group_type`
--
ALTER TABLE `cms_group_type`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT для таблицы `cms_high_school`
--
ALTER TABLE `cms_high_school`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID ВУЗа';

--
-- AUTO_INCREMENT для таблицы `cms_module`
--
ALTER TABLE `cms_module`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `cms_module_feedback`
--
ALTER TABLE `cms_module_feedback`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID сообщения';

--
-- AUTO_INCREMENT для таблицы `cms_module_order`
--
ALTER TABLE `cms_module_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT для таблицы `cms_module_page`
--
ALTER TABLE `cms_module_page`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT для таблицы `cms_module_review`
--
ALTER TABLE `cms_module_review`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID отзыва';

--
-- AUTO_INCREMENT для таблицы `cms_module_subject`
--
ALTER TABLE `cms_module_subject`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID предмета';

--
-- AUTO_INCREMENT для таблицы `cms_module_subject_category`
--
ALTER TABLE `cms_module_subject_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id';

--
-- AUTO_INCREMENT для таблицы `cms_payment`
--
ALTER TABLE `cms_payment`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT для таблицы `cms_question`
--
ALTER TABLE `cms_question`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT для таблицы `cms_quiz`
--
ALTER TABLE `cms_quiz`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID теста';

--
-- AUTO_INCREMENT для таблицы `cms_quiz_result`
--
ALTER TABLE `cms_quiz_result`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT для таблицы `cms_teacher`
--
ALTER TABLE `cms_teacher`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID учителя';

--
-- AUTO_INCREMENT для таблицы `cms_teacher_subject`
--
ALTER TABLE `cms_teacher_subject`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи';

--
-- AUTO_INCREMENT для таблицы `cms_user`
--
ALTER TABLE `cms_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `cms_webpage`
--
ALTER TABLE `cms_webpage`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `cms_widget_html`
--
ALTER TABLE `cms_widget_html`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `cms_widget_menu`
--
ALTER TABLE `cms_widget_menu`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- AUTO_INCREMENT для таблицы `cms_widget_menu_item`
--
ALTER TABLE `cms_widget_menu_item`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID';

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `cms_action`
--
ALTER TABLE `cms_action`
  ADD CONSTRAINT `cms_action_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `cms_user` (`id`),
  ADD CONSTRAINT `cms_action_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `cms_user` (`id`),
  ADD CONSTRAINT `cms_action_ibfk_3` FOREIGN KEY (`group_id`) REFERENCES `cms_group` (`id`);

--
-- Ограничения внешнего ключа таблицы `cms_auth`
--
ALTER TABLE `cms_auth`
  ADD CONSTRAINT `cms_auth_cms_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `cms_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_contract`
--
ALTER TABLE `cms_contract`
  ADD CONSTRAINT `cms_contract_cms_group_id_fk` FOREIGN KEY (`group_id`) REFERENCES `cms_group` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_contract_cms_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `cms_user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `contract_created_user_id_fk` FOREIGN KEY (`created_admin_id`) REFERENCES `cms_user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `contract_paid_user_id_fk` FOREIGN KEY (`paid_admin_id`) REFERENCES `cms_user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_debt`
--
ALTER TABLE `cms_debt`
  ADD CONSTRAINT `cms_debt_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `cms_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_event`
--
ALTER TABLE `cms_event`
  ADD CONSTRAINT `cms_event_ibfk_3` FOREIGN KEY (`group_id`) REFERENCES `cms_group` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_event_member`
--
ALTER TABLE `cms_event_member`
  ADD CONSTRAINT `cms_event_member_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `cms_event` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_event_member_ibfk_3` FOREIGN KEY (`group_pupil_id`) REFERENCES `cms_group_pupil` (`id`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_group`
--
ALTER TABLE `cms_group`
  ADD CONSTRAINT `cms_group_cms_group_type_id_fk` FOREIGN KEY (`type_id`) REFERENCES `cms_group_type` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_group_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `cms_module_subject` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_group_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `cms_teacher` (`id`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_group_param`
--
ALTER TABLE `cms_group_param`
  ADD CONSTRAINT `cms_group_param_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `cms_group` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_group_param_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `cms_teacher` (`id`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_group_pupil`
--
ALTER TABLE `cms_group_pupil`
  ADD CONSTRAINT `cms_group_pupil_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `cms_user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_group_pupil_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `cms_group` (`id`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_module_page`
--
ALTER TABLE `cms_module_page`
  ADD CONSTRAINT `cms_module_page_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `cms_webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_module_subject`
--
ALTER TABLE `cms_module_subject`
  ADD CONSTRAINT `cms_module_subject_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `cms_module_subject_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_module_subject_ibfk_2` FOREIGN KEY (`webpage_id`) REFERENCES `cms_webpage` (`id`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_module_subject_category`
--
ALTER TABLE `cms_module_subject_category`
  ADD CONSTRAINT `cms_module_subject_category_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `cms_webpage` (`id`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_payment`
--
ALTER TABLE `cms_payment`
  ADD CONSTRAINT `cms_payment_cms_contract_id_fk` FOREIGN KEY (`contract_id`) REFERENCES `cms_contract` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_payment_cms_group_id_fk` FOREIGN KEY (`group_id`) REFERENCES `cms_group` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_payment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `cms_user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_payment_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `cms_user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_payment_ibfk_4` FOREIGN KEY (`used_payment_id`) REFERENCES `cms_payment` (`id`),
  ADD CONSTRAINT `cms_payment_ibfk_5` FOREIGN KEY (`group_pupil_id`) REFERENCES `cms_group_pupil` (`id`),
  ADD CONSTRAINT `cms_payment_ibfk_6` FOREIGN KEY (`event_id`) REFERENCES `cms_event` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_payment_ibfk_7` FOREIGN KEY (`event_member_id`) REFERENCES `cms_event_member` (`id`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_question`
--
ALTER TABLE `cms_question`
  ADD CONSTRAINT `cms_question_ibfk_1` FOREIGN KEY (`quiz_id`) REFERENCES `cms_quiz` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cms_question_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `cms_question` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_quiz`
--
ALTER TABLE `cms_quiz`
  ADD CONSTRAINT `cms_quiz_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `cms_module_subject` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_teacher`
--
ALTER TABLE `cms_teacher`
  ADD CONSTRAINT `cms_teacher_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `cms_webpage` (`id`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_teacher_subject`
--
ALTER TABLE `cms_teacher_subject`
  ADD CONSTRAINT `cms_teacher_subject_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `cms_teacher` (`id`),
  ADD CONSTRAINT `cms_teacher_subject_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `cms_module_subject` (`id`);

--
-- Ограничения внешнего ключа таблицы `cms_user`
--
ALTER TABLE `cms_user`
  ADD CONSTRAINT `cms_user_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `cms_user` (`id`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_webpage`
--
ALTER TABLE `cms_webpage`
  ADD CONSTRAINT `cms_webpage_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `cms_module` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
